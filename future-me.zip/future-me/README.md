# Future Me — Time Capsules 🔒⏳

**"Leave something for your future self."**

Write letters, collect memories, set goals — seal them behind a countdown until
the right day comes. A complete time-capsule feature for Next.js (App Router +
Tailwind + shadcn/ui + Prisma/SQLite).

## Highlights

- 8 capsule types · 6 lock types (date, "after X days", birthday, new year, event, surprise)
- Locked countdown with fully hidden content, pure-CSS envelope seal/open animations
- Goal check-ins (✅/🟡/❌ + reflection), **Then vs Now** comparison
- Recurring yearly capsules, **Surprise capsules** ("open when you're having a bad day")
- Locked/Opened library with filters, year-grouped Timeline, Profile stats
- 7 capsule themes, warm nostalgic paper design, light/dark mode
- Auto-seeded with 8 demo capsules so it never looks empty

## Quick start (standalone)

```bash
cp .env.example .env
bun install          # or npm install
bunx prisma generate # or npx prisma generate
bun run dev          # → http://localhost:3000
```

## Adding it to an existing app

See **[INTEGRATION.md](./INTEGRATION.md)** — a copy-paste guide for dropping the
feature (`src/components/future-me/` + API routes + Prisma models + CSS) into any
Next.js App Router project in ~15 minutes.

## Stack

Next.js 16 · React 19 · TypeScript · Tailwind CSS 4 · shadcn/ui ·
TanStack Query · Prisma + SQLite · next-themes
