# Future Me — Time Capsule Feature

**"Leave something for your future self."**

A complete, production-ready time-capsule feature for Next.js: write letters, collect
memories, set goals — seal them behind a countdown until the right day comes.

Feature set:

- **8 capsule types** — Letter, Memory box, Goal, Photos, Video, Voice, Song, Custom
- **6 lock types** — specific date & time, "after X days", Birthday, New Year, custom event, Surprise capsule ("open when you're having a bad day")
- **Locked countdown hero** (d/h/m/s) with content fully hidden until unlock
- **Pure-CSS seal & open animations** (envelope + wax seal — no animation lib quirks)
- **Goal check-in** — ✅ Yes / 🟡 Almost / ❌ Not yet + written reflection
- **Then vs Now** — "What I wanted..." vs "What actually happened..."
- **Recurring capsules** — e.g. yearly birthday capsule, auto re-sealed after opening
- **Capsules view** — Locked / Opened tabs + `All | Letters | Memories | Goals | Media` filters
- **Timeline** — year-grouped archive of everything you've left yourself
- **Profile stats** — longest wait, goals achieved, bad days saved, by-type bars
- **7 visual themes** per capsule — Letter, Polaroid, Diary, Film, Archive, Minimal, Scrapbook
- Warm nostalgic paper design (Fraunces serif + Caveat handwriting, wax seals, washi tape), light/dark mode

---

## What's in this ZIP

```
future-me/
├── INTEGRATION.md            ← you are here
├── README.md                 ← quick overview
├── .env.example              ← copy to .env (DATABASE_URL)
├── package.json              ← reference deps (see Step 2 below)
├── prisma/schema.prisma      ← Capsule + CapsuleMedia + AppMeta models
├── db/custom.db              ← SQLite DB with 8 demo capsules
├── src/
│   ├── app/
│   │   ├── page.tsx                       ← mounts <FutureMeApp /> (single route)
│   │   ├── layout.tsx                     ← fonts + ThemeProvider + Toaster
│   │   ├── globals.css                    ← paper theme + all custom CSS (marked section)
│   │   └── api/capsules/
│   │       ├── route.ts                   ← GET (list) / POST (create, auto-seed)
│   │       └── [id]/route.ts              ← GET / PATCH (open, goal_outcome, reflection) / DELETE
│   ├── components/future-me/              ← ★ THE FEATURE (self-contained)
│   │   ├── app.tsx                        ← shell + bottom nav (Home/Create/Capsules/Timeline/Profile)
│   │   ├── api.ts, hooks.ts               ← TanStack Query data layer
│   │   ├── views/home.tsx, create.tsx, capsules.tsx, timeline.tsx, profile.tsx
│   │   ├── capsule-card.tsx, capsule-detail.tsx
│   │   ├── countdown.tsx, envelope.tsx, media-inputs.tsx
│   └── lib/
│       ├── capsules.ts                    ← types, themes, lock types, date/countdown helpers
│       ├── seed.ts                        ← 8 demo capsules (runs once)
│       └── db.ts                          ← Prisma client singleton
└── components.json            ← shadcn/ui config (reference)
```

The feature is **fully self-contained**: `src/components/future-me/` owns its own
`QueryClientProvider`, view-state navigation (no router changes needed), and API layer.
You can mount it at any route in an existing Next.js app.

---

## Option A — Run standalone (preview it as-is)

Requires [Bun](https://bun.sh) (or Node 20+ / npm — same scripts work with npx).

```bash
cd future-me
cp .env.example .env              # SQLite path (relative to prisma/schema.prisma)
bun install                       # or: npm install
bunx prisma generate              # or: npx prisma generate
bun run dev                       # or: npm run dev
```

Open **http://localhost:3000** — it ships with 8 demo capsules (a 12-day letter, a
2-month memory box, the "Learn SQL" goal due Dec 24, a bad-day surprise capsule,
and 3 already-opened ones with reflections).

> The included `db/custom.db` already has demo data. To start empty, see
> "Demo data" at the bottom.

---

## Option B — Merge into your existing Next.js app

### Requirements

- Next.js **App Router** (built & verified on Next 16, works on 14+)
- React 19, TypeScript
- **Tailwind CSS v4** (the CSS uses `@theme inline` + oklch vars — if you're on v3, see the note in Step 6)
- Prisma 6 with **SQLite** (easy to swap to Postgres — see Step 3 note)
- shadcn/ui initialized in your project

### Step 1 — Install the extra dependencies

```bash
bun add @tanstack/react-query date-fns framer-motion lucide-react next-themes
bun add prisma @prisma/client
```

(Skip any you already have — most apps have lucide-react and next-themes.)

### Step 2 — Copy the feature files

Copy from this ZIP into your project (same paths):

```
src/components/future-me/     ← the whole folder (11 files)
src/lib/capsules.ts
src/lib/seed.ts
src/app/api/capsules/         ← the whole folder (route.ts + [id]/route.ts)
```

If you **already have** a `src/lib/db.ts` (Prisma client), keep yours — the
feature only does `import { db } from "@/lib/db"`. If you don't, copy
`src/lib/db.ts` too.

### Step 3 — Add the Prisma models

Merge the three models from `prisma/schema.prisma` into your schema:

- `Capsule` — all capsule data + lock/unlock/recurring/goal fields
- `CapsuleMedia` — photo/video/voice/song attachments (cascade delete)
- `AppMeta` — tiny key/value store used for the one-time seed flag

Then:

```bash
bunx prisma generate
bunx prisma db push        # creates the tables
```

Using Postgres/MySQL instead of SQLite? The models are provider-agnostic — just
keep your own `datasource db` block. One caveat: media is stored inline as data
URLs (fine for a demo). For production, swap `CapsuleMedia.url` to a file/S3 URL.

### Step 4 — Environment

Add to `.env` (adjust the path to wherever you want the SQLite file):

```
DATABASE_URL=file:./db/custom.db
```

### Step 5 — shadcn/ui components used

The feature imports these — add any that are missing:

```bash
npx shadcn@latest add button input textarea switch tabs skeleton alert-dialog
```

It also uses the shadcn toast hook `@/hooks/use-toast` (standard shadcn scaffold
file — if you use sonner instead, remap the two `useToast` usages).

### Step 6 — CSS (globals.css)

1. **Fonts** — add to your `@theme inline` block:

```css
--font-serif: var(--font-fraunces), Georgia, serif;
--font-hand: var(--font-caveat), "Segoe Script", cursive;
```

2. **Palette** — copy the `:root { … }` and `.dark { … }` variable blocks from
this ZIP's `globals.css` (the "Warm paper / nostalgic palette" section) **only if
you want the whole app to adopt the paper look**. To keep your own brand colors,
skip this — the capsule views will still work with your palette.

3. **Custom styles** — append everything from the marker
`/* ---------- Future Me custom styles ---------- */` to the end of the file
(paper grain, ruled letter paper, washi tape, wax seal + envelope animations).
This section is namespaced under `.paper-bg`, `.fm-*` etc. and won't clash with
your styles.

> **Tailwind v3?** Replace the `@theme inline` font vars with
> `tailwind.config.ts` `fontFamily` entries (`serif` → fraunces, `hand` → caveat)
> and keep the rest of the CSS as-is.

### Step 7 — Root layout (fonts + providers)

In `src/app/layout.tsx`:

```tsx
import { Fraunces, Caveat } from "next/font/google";

const fraunces = Fraunces({ variable: "--font-fraunces", subsets: ["latin"], weight: ["400","500","600","700"], style: ["normal","italic"] });
const caveat = Caveat({ variable: "--font-caveat", subsets: ["latin"], weight: ["400","500","600","700"] });

// on <body>:
className={`${fraunces.variable} ${caveat.variable} ...`}
```

And wrap children with the providers the feature expects (skip ones you have):

```tsx
<ThemeProvider attribute="class" defaultTheme="system" enableSystem>
  {children}
  <Toaster />   {/* from @/components/ui/toaster */}
</ThemeProvider>
```

> `QueryClientProvider` is **inside** `FutureMeApp` — you don't need to add
> React Query to your root layout.

### Step 8 — Mount it

The app is **view-state driven**: one route, bottom nav switches views internally.

**As a page inside your app:**

```tsx
// src/app/future-me/page.tsx
import { FutureMeApp } from "@/components/future-me/app";

export default function Page() {
  return <FutureMeApp />;
}
```

**Or as your home page:** replace the content of `src/app/page.tsx` with the same
two lines.

If you already have a global nav/sidebar and don't want the built-in bottom nav,
hide it by passing `chrome={false}`? — not built in; instead simply don't render
`app.tsx` and compose the five views (`views/*`) with your own navigation — each
view is a standalone component taking no props and reading the shared hooks.

### Step 9 — Done

Open the route in your browser. On the first API call the DB auto-seeds 8 demo
capsules so nothing looks empty.

---

## Demo data

`src/lib/seed.ts` runs once (guarded by the `AppMeta { key: "seeded" }` flag).

**To start with a clean slate:**

```bash
sqlite3 db/custom.db "INSERT INTO AppMeta (key, value) VALUES ('seeded', '1');"
# or simply delete the demo rows:
sqlite3 db/custom.db "DELETE FROM CapsuleMedia; DELETE FROM Capsule; INSERT INTO AppMeta (key, value) VALUES ('seeded','1');"
```

Or remove the `seedIfEmpty()` call from `src/app/api/capsules/route.ts` before
first launch.

## Good to know

- **Media storage** — photos/voice/video are saved as data URLs in SQLite. Great
  for demos; swap to blob/S3 URLs for production scale.
- **Recurring capsules** — when a `recurring: "yearly"` capsule is opened, the API
  automatically creates the next year's sealed copy.
- **Surprise capsules** have no unlock date — they open only through the
  double-confirm "I need this today." flow.
- **Countdown accuracy** — lock types like "after X days" / birthday / new-year are
  normalized to an absolute `unlockDate` at creation time.
- All UI text is in English; copy lives inline in the components — easy to
  localize (e.g. with next-intl).
