import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const capsule = await db.capsule.findUnique({
      where: { id },
      include: { media: true },
    });
    if (!capsule) {
      return NextResponse.json({ error: "Capsule not found" }, { status: 404 });
    }
    return NextResponse.json({ capsule });
  } catch (err) {
    console.error("GET /api/capsules/[id] failed:", err);
    return NextResponse.json({ error: "Failed to load capsule" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await req.json();
    const action = String(body.action || "");

    const capsule = await db.capsule.findUnique({ where: { id }, include: { media: true } });
    if (!capsule) {
      return NextResponse.json({ error: "Capsule not found" }, { status: 404 });
    }

    if (action === "open") {
      if (capsule.status === "opened") {
        return NextResponse.json({ capsule });
      }
      const opened = await db.capsule.update({
        where: { id },
        data: { status: "opened", openedAt: new Date() },
        include: { media: true },
      });

      // Recurring capsules: create the next edition (e.g. every birthday / every year)
      if (capsule.recurring === "yearly") {
        const base = capsule.unlockDate ? new Date(capsule.unlockDate) : new Date();
        const next = new Date(base);
        next.setFullYear(next.getFullYear() + 1);
        if (capsule.lockType === "birthday") {
          // Re-compute next occurrence relative to now
          const now = new Date();
          const candidate = new Date(now.getFullYear(), base.getMonth(), base.getDate(), 9, 0, 0, 0);
          next.setTime((candidate > now ? candidate : new Date(now.getFullYear() + 1, base.getMonth(), base.getDate(), 9, 0, 0, 0)).getTime());
        }
        await db.capsule.create({
          data: {
            type: capsule.type,
            title: capsule.title,
            content: capsule.content,
            message: capsule.message,
            mood: capsule.mood,
            location: capsule.location,
            tags: capsule.tags,
            theme: capsule.theme,
            lockType: capsule.lockType,
            lockLabel: capsule.lockLabel,
            unlockDate: next,
            unlockDays: null,
            isSurprise: false,
            recurring: capsule.recurring,
          },
        });
      }

      return NextResponse.json({ capsule: opened });
    }

    if (action === "goal_outcome") {
      const outcome = String(body.goalOutcome || "");
      if (!["yes", "almost", "not_yet"].includes(outcome)) {
        return NextResponse.json({ error: "Invalid goal outcome" }, { status: 400 });
      }
      const updated = await db.capsule.update({
        where: { id },
        data: {
          goalOutcome: outcome,
          reflection: body.reflection ? String(body.reflection) : capsule.reflection,
        },
        include: { media: true },
      });
      return NextResponse.json({ capsule: updated });
    }

    if (action === "reflection") {
      const updated = await db.capsule.update({
        where: { id },
        data: { reflection: body.reflection ? String(body.reflection) : null },
        include: { media: true },
      });
      return NextResponse.json({ capsule: updated });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    console.error("PATCH /api/capsules/[id] failed:", err);
    return NextResponse.json({ error: "Failed to update capsule" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await db.capsule.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/capsules/[id] failed:", err);
    return NextResponse.json({ error: "Failed to delete capsule" }, { status: 500 });
  }
}
