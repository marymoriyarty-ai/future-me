import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { seedIfEmpty } from "@/lib/seed";
import { computeUnlockDate, type LockType } from "@/lib/capsules";

const VALID_TYPES = ["letter", "memory", "goal", "photos", "video", "voice", "song", "custom"];
const VALID_LOCKS = ["date", "days", "birthday", "new_year", "event", "surprise"];

export async function GET() {
  try {
    await seedIfEmpty();
    const capsules = await db.capsule.findMany({
      include: { media: true },
      orderBy: [{ createdAt: "desc" }],
    });
    // Sort: soonest unlock first, capsules without date last
    capsules.sort((a, b) => {
      const ax = a.unlockDate ? new Date(a.unlockDate).getTime() : Number.MAX_SAFE_INTEGER;
      const bx = b.unlockDate ? new Date(b.unlockDate).getTime() : Number.MAX_SAFE_INTEGER;
      return ax - bx;
    });
    return NextResponse.json({ capsules });
  } catch (err) {
    console.error("GET /api/capsules failed:", err);
    return NextResponse.json({ error: "Failed to load capsules" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const type = String(body.type || "");
    const title = String(body.title || "").trim();
    const lockType = String(body.lockType || "date") as LockType;

    if (!VALID_TYPES.includes(type)) {
      return NextResponse.json({ error: "Invalid capsule type" }, { status: 400 });
    }
    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }
    if (!VALID_LOCKS.includes(lockType)) {
      return NextResponse.json({ error: "Invalid lock type" }, { status: 400 });
    }

    const unlockDate = lockType === "surprise" ? null : computeUnlockDate(lockType, {
      date: body.lockDate,
      time: body.lockTime,
      days: typeof body.unlockDays === "number" ? body.unlockDays : undefined,
      birthday: body.birthday,
    });

    if (lockType !== "surprise" && !unlockDate) {
      return NextResponse.json({ error: "Could not compute the unlock date" }, { status: 400 });
    }
    if (unlockDate && unlockDate.getTime() < Date.now() - 60000) {
      return NextResponse.json({ error: "The unlock date must be in the future" }, { status: 400 });
    }

    const media = Array.isArray(body.media)
      ? body.media
          .filter((m: { kind?: string; url?: string }) => m && m.kind && m.url)
          .slice(0, 12)
          .map((m: { kind: string; url: string; caption?: string }) => ({
            kind: String(m.kind),
            url: String(m.url),
            caption: m.caption ? String(m.caption) : null,
          }))
      : [];

    const capsule = await db.capsule.create({
      data: {
        type,
        title,
        content: body.content ? String(body.content) : "",
        message: body.message ? String(body.message) : null,
        mood: body.mood ? String(body.mood) : null,
        location: body.location ? String(body.location) : null,
        tags: body.tags ? String(body.tags) : null,
        theme: body.theme ? String(body.theme) : "letter",
        lockType,
        lockLabel: body.lockLabel ? String(body.lockLabel) : null,
        unlockDate,
        unlockDays: typeof body.unlockDays === "number" ? body.unlockDays : null,
        isSurprise: Boolean(body.isSurprise) || lockType === "surprise",
        recurring: body.recurring ? String(body.recurring) : null,
        media: { create: media },
      },
      include: { media: true },
    });

    return NextResponse.json({ capsule }, { status: 201 });
  } catch (err) {
    console.error("POST /api/capsules failed:", err);
    return NextResponse.json({ error: "Failed to create capsule" }, { status: 500 });
  }
}
