import { FutureMeApp } from "@/components/future-me/app";

export default function Page() {
  return <FutureMeApp />;
}
