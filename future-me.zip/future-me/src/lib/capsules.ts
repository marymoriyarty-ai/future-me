// Shared types & helpers for the Future Me time capsule app

export type CapsuleType =
  | "letter"
  | "memory"
  | "goal"
  | "photos"
  | "video"
  | "voice"
  | "song"
  | "custom";

export type LockType =
  | "date" // specific date
  | "days" // after X days
  | "birthday"
  | "new_year"
  | "event" // custom event with label
  | "surprise"; // open when needed

export type CapsuleTheme =
  | "letter"
  | "polaroid"
  | "diary"
  | "film"
  | "archive"
  | "minimal"
  | "scrapbook";

export interface CapsuleMediaDTO {
  id: string;
  kind: "photo" | "video" | "voice" | "song";
  url: string;
  caption?: string | null;
}

export interface CapsuleDTO {
  id: string;
  type: CapsuleType;
  title: string;
  content: string;
  message?: string | null;
  mood?: string | null;
  location?: string | null;
  tags?: string | null;
  theme: CapsuleTheme;
  lockType: LockType;
  lockLabel?: string | null;
  unlockDate?: string | null;
  unlockDays?: number | null;
  isSurprise: boolean;
  recurring?: string | null;
  status: "locked" | "opened";
  goalOutcome?: "yes" | "almost" | "not_yet" | null;
  reflection?: string | null;
  createdAt: string;
  openedAt?: string | null;
  media: CapsuleMediaDTO[];
}

export const TYPE_META: Record<
  CapsuleType,
  { emoji: string; label: string; hint: string }
> = {
  letter: { emoji: "💌", label: "Letter", hint: "A letter to future you" },
  memory: { emoji: "📦", label: "Memory box", hint: "Collect a moment" },
  goal: { emoji: "🎯", label: "Goal", hint: "Did we make it?" },
  photos: { emoji: "📸", label: "Photos", hint: "Freeze this moment" },
  video: { emoji: "🎥", label: "Video", hint: "Say it on camera" },
  voice: { emoji: "🎙️", label: "Voice message", hint: "In your own voice" },
  song: { emoji: "🎵", label: "Song / playlist", hint: "A soundtrack for later" },
  custom: { emoji: "✨", label: "Custom", hint: "Anything you like" },
};

export const THEME_META: Record<
  CapsuleTheme,
  { label: string; gradient: string; chip: string; paper: string }
> = {
  letter: {
    label: "Letter",
    gradient: "from-indigo-200 to-cyan-200",
    chip: "bg-indigo-500/15 text-indigo-800 dark:text-indigo-300",
    paper: "bg-[#1f2438] text-indigo-50 border-indigo-900/60",
  },
  polaroid: {
    label: "Polaroid",
    gradient: "from-slate-200 to-zinc-300",
    chip: "bg-slate-500/15 text-slate-700 dark:text-slate-300",
    paper: "bg-[#232230] text-zinc-100 border-zinc-700/60",
  },
  diary: {
    label: "Diary",
    gradient: "from-fuchsia-200 to-purple-200",
    chip: "bg-fuchsia-500/15 text-fuchsia-800 dark:text-fuchsia-300",
    paper: "bg-[#2a1f33] text-fuchsia-50 border-fuchsia-900/60",
  },
  film: {
    label: "Film",
    gradient: "from-zinc-700 to-zinc-900",
    chip: "bg-zinc-500/20 text-zinc-700 dark:text-zinc-300",
    paper: "bg-[#141220] text-zinc-100 border-zinc-700/60",
  },
  archive: {
    label: "Archive",
    gradient: "from-emerald-200 to-teal-200",
    chip: "bg-emerald-500/15 text-emerald-800 dark:text-emerald-300",
    paper: "bg-[#182721] text-emerald-50 border-emerald-900/60",
  },
  minimal: {
    label: "Minimal",
    gradient: "from-neutral-200 to-slate-200",
    chip: "bg-neutral-500/15 text-neutral-700 dark:text-neutral-300",
    paper: "bg-[#201f2b] text-neutral-100 border-neutral-700/60",
  },
  scrapbook: {
    label: "Scrapbook",
    gradient: "from-amber-200 to-yellow-100",
    chip: "bg-amber-500/15 text-amber-800 dark:text-amber-300",
    paper: "bg-[#2a2414] text-amber-50 border-amber-900/60",
  },
};

export const GOAL_OUTCOMES = [
  { key: "yes", emoji: "✅", label: "Yes, we did it!" },
  { key: "almost", emoji: "🟡", label: "Almost there" },
  { key: "not_yet", emoji: "❌", label: "Not yet" },
] as const;

/** Compute the absolute unlock date from lock settings. Returns null for surprise-only. */
export function computeUnlockDate(
  lockType: LockType,
  opts: { date?: string; time?: string; days?: number; birthday?: string }
): Date | null {
  const now = new Date();
  switch (lockType) {
    case "date":
    case "event": {
      if (!opts.date) return null;
      const [y, m, d] = opts.date.split("-").map(Number);
      let hh = 9;
      let mm = 0;
      if (opts.time) {
        const [a, b] = opts.time.split(":").map(Number);
        hh = a;
        mm = b;
      }
      return new Date(y, (m || 1) - 1, d || 1, hh, mm, 0, 0);
    }
    case "days": {
      const n = Math.max(1, opts.days || 1);
      return new Date(now.getTime() + n * 24 * 60 * 60 * 1000);
    }
    case "birthday": {
      if (!opts.birthday) return null;
      const [, bm, bd] = opts.birthday.split("-").map(Number);
      const thisYear = new Date(now.getFullYear(), bm - 1, bd, 9, 0, 0, 0);
      if (thisYear > now) return thisYear;
      return new Date(now.getFullYear() + 1, bm - 1, bd, 9, 0, 0, 0);
    }
    case "new_year": {
      return new Date(now.getFullYear() + 1, 0, 1, 0, 0, 0, 0);
    }
    case "surprise":
      return null;
    default:
      return null;
  }
}

export function isReadyToOpen(c: CapsuleDTO, now = Date.now()): boolean {
  if (c.status === "opened") return false;
  if (c.isSurprise) return false; // surprise needs the "I need this today" action
  if (!c.unlockDate) return false;
  return new Date(c.unlockDate).getTime() <= now;
}

export interface Remaining {
  total: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function timeRemaining(target: string | Date, now = Date.now()): Remaining {
  const t = new Date(target).getTime();
  const total = Math.max(0, t - now);
  return {
    total,
    days: Math.floor(total / 86400000),
    hours: Math.floor((total % 86400000) / 3600000),
    minutes: Math.floor((total % 3600000) / 60000),
    seconds: Math.floor((total % 60000) / 1000),
  };
}

export function humanCountdown(r: Remaining): string {
  if (r.total <= 0) return "ready now";
  if (r.days >= 1) {
    const d = r.days;
    const h = r.hours;
    if (d > 60) return `${d} days`;
    return h > 0 ? `${d}d ${h}h` : `${d} days`;
  }
  if (r.hours >= 1) return `${r.hours}h ${r.minutes}m`;
  return `${r.minutes}m`;
}

export function lockTypeLabel(c: CapsuleDTO): string {
  switch (c.lockType) {
    case "date":
      return "Opens on a chosen date";
    case "days":
      return `Opens ${c.unlockDays} days after sealing`;
    case "birthday":
      return "Opens on your birthday";
    case "new_year":
      return "Opens on New Year's Day";
    case "event":
      return c.lockLabel ? `Opens on ${c.lockLabel}` : "Opens on a custom event";
    case "surprise":
      return "Open when you need it most";
  }
}

export function typeFilter(c: CapsuleDTO, filter: string): boolean {
  switch (filter) {
    case "letters":
      return c.type === "letter";
    case "memories":
      return c.type === "memory";
    case "goals":
      return c.type === "goal";
    case "media":
      return ["photos", "video", "voice", "song"].includes(c.type);
    default:
      return true;
  }
}
