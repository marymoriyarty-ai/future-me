import { db } from "@/lib/db";

// Small inline SVG placeholder "photos" so seeded memory capsules have visuals
function svgPhoto(a: string, b: string, label: string): string {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='640' height='480'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient></defs><rect width='640' height='480' fill='url(#g)'/><circle cx='500' cy='110' r='60' fill='rgba(255,255,255,0.55)'/><path d='M0 360 L160 250 L300 370 L440 280 L640 400 L640 480 L0 480 Z' fill='rgba(255,255,255,0.35)'/><text x='32' y='440' font-family='Georgia, serif' font-size='26' fill='rgba(60,40,20,0.65)'>${label}</text></svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}

function addDays(n: number): Date {
  return new Date(Date.now() + n * 24 * 60 * 60 * 1000);
}

function addMonths(n: number): Date {
  const d = new Date();
  d.setMonth(d.getMonth() + n);
  return d;
}

function dec24(): Date {
  const now = new Date();
  const d = new Date(now.getFullYear(), 11, 24, 9, 0, 0, 0);
  if (d <= now) return new Date(now.getFullYear() + 1, 11, 24, 9, 0, 0, 0);
  return d;
}

function dec31(): Date {
  return new Date(new Date().getFullYear(), 11, 31, 23, 59, 0, 0);
}

export async function seedIfEmpty(): Promise<void> {
  const meta = await db.appMeta.findUnique({ where: { key: "seeded" } });
  if (meta) return;

  const count = await db.capsule.count();
  if (count === 0) {
    await db.capsule.create({
      data: {
        type: "letter",
        title: "Open this when you need a reminder",
        content:
          "Dear Future Me,\n\nRight now, life is simple in the best way. Morning coffee, small wins, big dreams. I hope you kept your promise of learning something new every week, and I hope you still laugh at the same silly jokes.\n\nDon't forget where you started. Be proud of how far you've come.\n\n— Past you, with love.",
        mood: "🌤️",
        location: "Home",
        tags: "reminder,love",
        theme: "letter",
        lockType: "date",
        unlockDate: addDays(12),
      },
    });
    await db.capsule.create({
      data: {
        type: "memory",
        title: "This is what my life looks like right now",
        content:
          "A random Tuesday: warm light on the desk, a to-do list half done, and the feeling that something good is coming. Keep this feeling.",
        mood: "☺️",
        location: "My room",
        tags: "everyday",
        theme: "polaroid",
        lockType: "days",
        unlockDays: 60,
        unlockDate: addMonths(2),
        media: {
          create: [
            {
              kind: "photo",
              url: svgPhoto("#6d28d9", "#be185d", "Violet dusk"),
              caption: "Golden afternoon light",
            },
            {
              kind: "photo",
              url: svgPhoto("#312e81", "#7c3aed", "Quiet moonlight"),
              caption: "Quiet morning walk",
            },
          ],
        },
      },
    });
    await db.capsule.create({
      data: {
        type: "goal",
        title: "Learn SQL",
        content:
          "Go from zero to comfortable: SELECTs, JOINs, GROUP BY, and designing a small schema by myself. Practice 30 minutes a day.",
        message: "Did we do it?",
        mood: "🎯",
        theme: "minimal",
        lockType: "date",
        unlockDate: dec24(),
      },
    });
    await db.capsule.create({
      data: {
        type: "letter",
        title: "End of the year",
        content:
          "Dear Future Me,\n\nBy the time you read this, the year is over. Whatever happened — the plans that worked, the ones that didn't — you made it here.\n\nTake one deep breath. Then let's write the next chapter.\n\nHappy new year. 🎆",
        mood: "🎆",
        theme: "film",
        lockType: "new_year",
        unlockDate: dec31(),
      },
    });
    await db.capsule.create({
      data: {
        type: "letter",
        title: "Open this when you're having a bad day",
        content:
          "Hey. Breathe.\n\nYou have survived every single bad day so far — that's a 100% success rate. Whatever is happening right now is temporary, and you don't have to fix everything today.\n\nDrink some water. Step outside for two minutes. I believe in you.\n\n— You, from a better moment.",
        mood: "🤍",
        theme: "diary",
        lockType: "surprise",
        isSurprise: true,
      },
    });
    await db.capsule.create({
      data: {
        type: "letter",
        title: "Letter from 2025",
        content:
          "Dear Future Me,\n\nToday I'm starting this habit of writing to you. I want to be braver this year — speak up, ship the project, call grandma more often.\n\nI hope at least one of these came true.\n\n— Past you",
        mood: "✨",
        theme: "letter",
        lockType: "new_year",
        unlockDate: new Date(new Date().getFullYear(), 0, 1, 0, 5, 0, 0),
        status: "opened",
        openedAt: new Date(new Date().getFullYear(), 0, 1, 12, 0, 0, 0),
        createdAt: new Date(new Date().getFullYear() - 1, 8, 25, 10, 0, 0, 0),
        reflection:
          "Then: I wanted to be braver and call grandma more.\n\nNow: I shipped the project AND started a weekly call with grandma. Braver than last year — proof that future me shows up.",
      },
    });
    await db.capsule.create({
      data: {
        type: "goal",
        title: "Run 5k without stopping",
        content: "Build up from couch to 5k. Three runs a week, no excuses on Sundays.",
        message: "Did we do it?",
        mood: "🏃",
        theme: "archive",
        lockType: "days",
        unlockDays: 120,
        unlockDate: addMonths(-2),
        status: "opened",
        openedAt: addMonths(-2),
        createdAt: addMonths(-6),
        goalOutcome: "yes",
        reflection:
          "35 minutes, no walking breaks, and honestly the last kilometer felt good. Next goal: 10k.",
      },
    });
    await db.capsule.create({
      data: {
        type: "memory",
        title: "First semester capsule",
        content:
          "Week one of the semester: new notebooks, old fears, and a campus that slowly started feeling like home.",
        mood: "📚",
        theme: "scrapbook",
        lockType: "days",
        unlockDays: 150,
        unlockDate: addMonths(-3),
        status: "opened",
        openedAt: addMonths(-3),
        createdAt: addMonths(-8),
        reflection:
          "Reading this made me smile. The fears were bigger in my head than in real life.",
        media: {
          create: [
            {
              kind: "photo",
              url: svgPhoto("#4c1d95", "#9f1239", "Campus nights"),
              caption: "Campus days",
            },
          ],
        },
      },
    });
  }

  await db.appMeta.create({ data: { key: "seeded", value: "1" } });
}
