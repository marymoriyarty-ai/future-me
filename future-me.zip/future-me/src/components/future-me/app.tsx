"use client";

import { useEffect, useMemo, useState } from "react";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { Home, Archive, Clock, UserRound, Plus } from "lucide-react";
import type { CapsuleDTO } from "@/lib/capsules";
import { isReadyToOpen } from "@/lib/capsules";
import { useCapsules, useNow } from "./hooks";
import { HomeView } from "./views/home";
import { CreateView } from "./views/create";
import { CapsulesView } from "./views/capsules";
import { TimelineView } from "./views/timeline";
import { ProfileView } from "./views/profile";
import { CapsuleDetail } from "./capsule-detail";
import { InteractiveBackground } from "./interactive-background";

type View =
  | { name: "home" }
  | { name: "create" }
  | { name: "capsules" }
  | { name: "timeline" }
  | { name: "profile" }
  | { name: "detail"; id: string };

function BottomNav({
  view,
  onNavigate,
  onCreate,
  readyCount,
}: {
  view: View;
  onNavigate: (v: View) => void;
  onCreate: () => void;
  readyCount: number;
}) {
  const items = [
    { key: "home", icon: Home, label: "Home" },
    { key: "capsules", icon: Archive, label: "Capsules" },
    { key: "timeline", icon: Clock, label: "Timeline" },
    { key: "profile", icon: UserRound, label: "Profile" },
  ] as const;

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t bg-background/90 backdrop-blur-md pb-safe"
      aria-label="Main navigation"
    >
      <div className="mx-auto grid max-w-lg grid-cols-5 items-end px-2">
        {items.slice(0, 2).map(({ key, icon: Icon, label }) => (
          <NavButton key={key} active={view.name === key} onClick={() => onNavigate({ name: key } as View)} icon={<Icon className="h-5 w-5" />} label={label} />
        ))}

        {/* center create button — raised dock */}
        <div className="relative flex justify-center">
          <motion.button
            type="button"
            onClick={onCreate}
            whileTap={{ scale: 0.92 }}
            className="relative -mt-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 via-violet-600 to-fuchsia-500 text-white shadow-lg shadow-violet-500/40 ring-1 ring-cyan-300/30 transition-transform hover:scale-105"
            aria-label="Create capsule"
          >
            <Plus className="h-7 w-7" aria-hidden />
            {readyCount > 0 && (
              <span
                className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-amber-400 px-1 text-[10px] font-bold text-amber-950 ring-2 ring-background"
                aria-label={`${readyCount} ready to open`}
              >
                {readyCount}
              </span>
            )}
          </motion.button>
        </div>

        {items.slice(2).map(({ key, icon: Icon, label }) => (
          <NavButton key={key} active={view.name === key} onClick={() => onNavigate({ name: key } as View)} icon={<Icon className="h-5 w-5" />} label={label} />
        ))}
      </div>
    </nav>
  );
}

function NavButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-0.5 rounded-xl py-2.5 text-[10px] font-medium transition-colors ${
        active ? "text-primary" : "text-muted-foreground hover:text-foreground"
      }`}
      aria-current={active ? "page" : undefined}
    >
      {icon}
      {label}
    </button>
  );
}

function AppShell() {
  const [view, setView] = useState<View>({ name: "home" });
  const { data: capsules, isLoading } = useCapsules();
  const now = useNow(60000);
  const qc = useQueryClient();

  const list: CapsuleDTO[] = capsules || [];
  const selected = useMemo(
    () => (view.name === "detail" ? list.find((c) => c.id === view.id) || null : null),
    [view, list]
  );
  const readyCount = list.filter((c) => isReadyToOpen(c, now)).length;

  const openCapsule = (c: CapsuleDTO) => {
    qc.invalidateQueries({ queryKey: ["capsules"] });
    setView({ name: "detail", id: c.id });
  };

  // land at the top of a freshly opened view
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  return (
    <div className="paper-bg flex min-h-screen flex-col">
      <InteractiveBackground />
      <main className="flex-1 pb-36" role="main">
        <AnimatePresence mode="wait">
          <motion.div
            key={view.name === "detail" ? `detail-${view.id}` : view.name}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
          >
            {view.name === "home" && (
              <HomeView
                capsules={list}
                isLoading={isLoading}
                onOpenCapsule={openCapsule}
                onCreate={() => setView({ name: "create" })}
              />
            )}
            {view.name === "create" && (
              <CreateView
                onBack={() => setView({ name: "home" })}
                onCreated={() => setView({ name: "home" })}
              />
            )}
            {view.name === "capsules" && (
              <CapsulesView
                capsules={list}
                isLoading={isLoading}
                onOpenCapsule={openCapsule}
                onCreate={() => setView({ name: "create" })}
              />
            )}
            {view.name === "timeline" && <TimelineView capsules={list} onOpenCapsule={openCapsule} />}
            {view.name === "profile" && <ProfileView capsules={list} />}
            {view.name === "detail" &&
              (selected ? (
                <CapsuleDetail capsule={selected} onBack={() => setView({ name: "home" })} />
              ) : (
                <div className="mx-auto max-w-lg px-4 pt-16 text-center text-sm text-muted-foreground">
                  Capsule not found.{" "}
                  <button className="underline" onClick={() => setView({ name: "home" })}>
                    Go home
                  </button>
                </div>
              ))}
          </motion.div>
        </AnimatePresence>
      </main>

      <BottomNav view={view} onNavigate={setView} onCreate={() => setView({ name: "create" })} readyCount={readyCount} />
    </div>
  );
}

export function FutureMeApp() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { retry: 1, refetchOnWindowFocus: false },
        },
      })
  );
  return (
    <QueryClientProvider client={queryClient}>
      <AppShell />
    </QueryClientProvider>
  );
}
