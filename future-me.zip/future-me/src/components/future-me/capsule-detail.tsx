"use client";

import { useState } from "react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { ArrowLeft, MapPin, Trash2, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  TYPE_META,
  THEME_META,
  GOAL_OUTCOMES,
  lockTypeLabel,
  isReadyToOpen,
  type CapsuleDTO,
} from "@/lib/capsules";
import { EnvelopeOverlay } from "./envelope";
import { SealedHeroVisual } from "./sealed-visual";
import { useCapsuleMutations } from "./hooks";
import { TypeBadge } from "./capsule-card";

export function CapsuleDetail({
  capsule,
  onBack,
}: {
  capsule: CapsuleDTO;
  onBack: () => void;
}) {
  const { toast } = useToast();
  const { open, goal, reflect, remove } = useCapsuleMutations();
  const [anim, setAnim] = useState<"seal" | "open" | null>(null);
  const [reflection, setReflection] = useState(capsule.reflection || "");
  const [confirmedSurprise, setConfirmedSurprise] = useState(false);

  const theme = THEME_META[capsule.theme] || THEME_META.letter;
  const ready = isReadyToOpen(capsule);
  const opened = capsule.status === "opened";
  const isGoal = capsule.type === "goal";

  const handleOpen = () => {
    setAnim("open");
  };

  const revealContent = async () => {
    setAnim(null);
    try {
      await open.mutateAsync(capsule.id);
      toast({ title: "Capsule opened 💌" });
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Failed to open the capsule",
        variant: "destructive",
      });
    }
  };

  const handleSurpriseOpen = () => {
    if (!confirmedSurprise) {
      setConfirmedSurprise(true);
      return;
    }
    handleOpen();
  };

  const saveOutcome = async (outcome: string) => {
    try {
      await goal.mutateAsync({
        id: capsule.id,
        outcome,
        reflection: reflection || undefined,
      });
      toast({ title: "Answer saved. Future you says thanks." });
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Failed to save the answer",
        variant: "destructive",
      });
    }
  };

  const saveReflection = async () => {
    if (!reflection.trim()) return;
    try {
      await reflect.mutateAsync({ id: capsule.id, reflection });
      toast({ title: "Reflection saved" });
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Failed to save the reflection",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async () => {
    try {
      await remove.mutateAsync(capsule.id);
      toast({ title: "Capsule removed" });
      onBack();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Failed to delete",
        variant: "destructive",
      });
    }
  };

  const photos = capsule.media.filter((m) => m.kind === "photo");
  const voice = capsule.media.find((m) => m.kind === "voice");
  const video = capsule.media.find((m) => m.kind === "video");
  const song = capsule.media.find((m) => m.kind === "song");

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-6">
      <EnvelopeOverlay mode={anim} onDone={revealContent} />

      {/* header */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={onBack} aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${theme.chip}`}>
          {TYPE_META[capsule.type]?.emoji} {TYPE_META[capsule.type]?.label}
        </span>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="ml-auto text-muted-foreground" aria-label="Delete capsule">
              <Trash2 className="h-4 w-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete this capsule?</AlertDialogTitle>
              <AlertDialogDescription>
                {opened
                  ? "This will remove the memory forever. There's no undo."
                  : "Future you will never receive it. There's no undo."}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep it</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-white hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* LOCKED STATE — the capsule takes its own type's form, countdown inside */}
      {!opened && !ready && !capsule.isSurprise && (
        <div className="mt-6 text-center">
          <SealedHeroVisual capsule={capsule} withTitle={false} />
          <h1 className="mt-5 font-serif text-xl font-semibold">{capsule.title}</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Sealed {format(new Date(capsule.createdAt), "MMMM d, yyyy")}
            {capsule.unlockDate
              ? ` · opens ${format(new Date(capsule.unlockDate), "MMMM d, yyyy")}`
              : ""}
          </p>
          <p className="mt-2 font-hand text-lg text-muted-foreground">{lockTypeLabel(capsule)}</p>
          {capsule.recurring === "yearly" && (
            <p className="mt-1 text-xs text-muted-foreground">🔁 returns every year</p>
          )}
        </div>
      )}

      {/* SURPRISE STATE */}
      {!opened && capsule.isSurprise && (
        <div className="mt-6 text-center">
          <div className="relative overflow-hidden rounded-3xl border border-fuchsia-900/40 bg-gradient-to-br from-fuchsia-50 to-violet-50 p-8 shadow-sm dark:border-fuchsia-900/50 dark:from-fuchsia-950/40 dark:to-violet-950/40">
            <div className="text-4xl" aria-hidden>🎁</div>
            <h1 className="mt-3 font-serif text-xl font-semibold">{capsule.title}</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              No countdown. No date. Just a hand reaching from the past — exactly when you need it.
            </p>
            <Button
              size="lg"
              className="mt-6 font-serif text-lg"
              variant={confirmedSurprise ? "destructive" : "default"}
              onClick={handleSurpriseOpen}
            >
              {confirmedSurprise ? "Are you sure? Tap again to open" : "🤍 I need this today"}
            </Button>
            {confirmedSurprise && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-3 text-xs text-muted-foreground"
              >
                It will open for you right away.
              </motion.p>
            )}
          </div>
        </div>
      )}

      {/* READY STATE */}
      {!opened && ready && (
        <div className="mt-6 text-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative overflow-hidden rounded-3xl border border-primary/40 bg-gradient-to-br from-cyan-50 via-violet-100 to-indigo-100 p-8 shadow-md dark:from-cyan-950/40 dark:via-violet-950/60 dark:to-indigo-950/60"
          >
            <div className="tape mx-auto h-3 w-24 -rotate-3 rounded-sm" aria-hidden />
            <div className="wax-seal mx-auto mt-4 flex h-20 w-20 items-center justify-center rounded-full">
              <Gift className="h-7 w-7 text-fuchsia-100" aria-hidden />
            </div>
            <p className="mt-4 font-serif text-2xl font-semibold">The day has come.</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {capsule.unlockDate
                ? `Sealed on ${format(new Date(capsule.createdAt), "MMMM d, yyyy")} — unlocked today.`
                : "Time to open it."}
            </p>
            <Button size="lg" className="mt-6 gap-2 font-serif text-lg shadow-lg shadow-primary/30" onClick={handleOpen}>
              ✉️ Open Capsule
            </Button>
          </motion.div>
          <h1 className="mt-5 font-serif text-xl font-semibold">{capsule.title}</h1>
        </div>
      )}

      {/* OPENED STATE */}
      {opened && (
        <div className="mt-5 space-y-5 pb-6">
          {/* themed letter paper */}
          <div className={`${theme.paper} relative overflow-hidden rounded-3xl border shadow-sm`}>
            <div className="tape absolute left-1/2 top-0 h-3 w-28 -translate-x-1/2 -rotate-2 rounded-sm" aria-hidden />
            <div className="p-6 pt-8">
              <h1 className="font-serif text-2xl font-semibold leading-snug">{capsule.title}</h1>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <TypeBadge type={capsule.type} className={theme.chip} />
                {capsule.mood && <span aria-label="mood">{capsule.mood}</span>}
                {capsule.location && (
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" aria-hidden /> {capsule.location}
                  </span>
                )}
              </div>
              <p className="mt-4 font-hand text-lg text-muted-foreground/80">
                from {format(new Date(capsule.createdAt), "MMMM d, yyyy")}
              </p>

              {capsule.type === "letter" && (
                <p className="mt-4 font-serif text-lg leading-9 whitespace-pre-wrap">
                  {capsule.content}
                </p>
              )}

              {(capsule.type === "memory" || capsule.type === "custom" || capsule.type === "photos") &&
                capsule.content && (
                  <p className="mt-4 font-serif text-[15px] leading-8 whitespace-pre-wrap">
                    {capsule.content}
                  </p>
                )}

              {capsule.type === "song" && song?.caption && (
                <p className="mt-4 flex items-center gap-2 font-serif text-lg">
                  🎵 {song.caption}
                </p>
              )}
              {capsule.type === "song" && !song?.caption && capsule.content && (
                <p className="mt-4 font-serif text-[15px] leading-8 whitespace-pre-wrap">{capsule.content}</p>
              )}

              {/* media */}
              {photos.length > 0 && (
                <div className="mt-5 grid grid-cols-2 gap-3">
                  {photos.map((p, i) => (
                    <figure
                      key={p.id}
                      className={`overflow-hidden rounded-lg border bg-white shadow-md dark:border-neutral-700 ${
                        i % 2 === 0 ? "rotate-[-1.5deg]" : "rotate-[1.5deg]"
                      }`}
                    >
                      <img src={p.url} alt={p.caption || "Memory"} className="aspect-square w-full object-cover" />
                      <figcaption className="p-1.5 text-center font-hand text-sm text-neutral-600 dark:text-neutral-300">
                        {p.caption || "·"}
                      </figcaption>
                    </figure>
                  ))}
                </div>
              )}

              {video && (
                <video controls src={video.url} className="mt-5 w-full rounded-xl border bg-black" />
              )}
              {voice && (
                <div className="mt-5 rounded-xl border bg-white/60 p-3 dark:bg-white/5">
                  <p className="mb-1.5 font-hand text-base text-muted-foreground">🎙️ voice from the past</p>
                  <audio controls src={voice.url} className="w-full" />
                </div>
              )}
              {song && song.url && (
                <audio controls src={song.url} className="mt-4 w-full" />
              )}

              {capsule.tags && (
                <div className="mt-5 flex flex-wrap gap-1.5">
                  {capsule.tags.split(",").map((t) => (
                    <span key={t} className="rounded-full bg-black/5 px-2.5 py-0.5 text-[11px] dark:bg-white/10">
                      #{t.trim()}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* GOAL CHECK-IN */}
          {isGoal && (
            <div className="rounded-3xl border bg-card p-6 shadow-sm">
              <p className="text-center font-serif text-2xl font-semibold">
                {capsule.message || "Did you make it?"}
              </p>
              {capsule.goalOutcome ? (
                <div className="mt-4 text-center">
                  <p className="text-3xl" aria-hidden>
                    {GOAL_OUTCOMES.find((o) => o.key === capsule.goalOutcome)?.emoji}
                  </p>
                  <p className="mt-1 font-serif text-lg">
                    {GOAL_OUTCOMES.find((o) => o.key === capsule.goalOutcome)?.label}
                  </p>
                </div>
              ) : (
                <div className="mt-4 grid gap-2">
                  {GOAL_OUTCOMES.map((o) => (
                    <button
                      key={o.key}
                      type="button"
                      disabled={goal.isPending}
                      onClick={() => saveOutcome(o.key)}
                      className="flex items-center gap-3 rounded-2xl border bg-background p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-sm disabled:opacity-50"
                    >
                      <span className="text-xl" aria-hidden>{o.emoji}</span>
                      <span className="font-serif text-[15px]">{o.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* THEN vs NOW */}
          <div className="rounded-3xl border bg-card p-6 shadow-sm">
            <p className="font-serif text-lg font-semibold">🪞 Then vs Now</p>
            <div className="mt-3 grid gap-3">
              <div className="rounded-2xl border border-dashed p-4">
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Then</p>
                <p className="mt-1.5 whitespace-pre-wrap font-serif text-[15px] leading-7">
                  {capsule.content || capsule.title}
                </p>
              </div>
              {capsule.reflection ? (
                <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">Now</p>
                  <p className="mt-1.5 whitespace-pre-wrap font-serif text-[15px] leading-7">
                    {capsule.reflection}
                  </p>
                </div>
              ) : (
                <div className="rounded-2xl border p-4">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Now</p>
                  <p className="mb-2 mt-1 text-xs text-muted-foreground">
                    What actually happened? What would you tell your past self?
                  </p>
                  <Textarea
                    placeholder="Now: the honest answer…"
                    value={reflection}
                    onChange={(e) => setReflection(e.target.value)}
                    rows={3}
                  />
                  <Button size="sm" className="mt-2" onClick={saveReflection} disabled={reflect.isPending || !reflection.trim()}>
                    Save reflection
                  </Button>
                </div>
              )}
            </div>
          </div>

          <p className="pb-2 text-center text-xs text-muted-foreground">
            Created: {format(new Date(capsule.createdAt), "MMMM d, yyyy")} · Opened:{" "}
            {capsule.openedAt ? format(new Date(capsule.openedAt), "MMMM d, yyyy") : "—"}
          </p>
        </div>
      )}
    </div>
  );
}
