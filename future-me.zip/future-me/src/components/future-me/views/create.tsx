"use client";

import { useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, Sparkles, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import {
  TYPE_META,
  THEME_META,
  computeUnlockDate,
  type CapsuleType,
  type CapsuleTheme,
  type LockType,
} from "@/lib/capsules";
import { PhotoInput, VoiceRecorder, VideoInput, SongInput, type MediaItem } from "../media-inputs";
import { useCapsuleMutations } from "../hooks";
import { EnvelopeOverlay } from "../envelope";

const MOODS = ["☺️", "🌤️", "✨", "🔥", "🥲", "🎯", "🤍", "🎆", "📚", "🏃", "🎧", "🌙"];

const TYPE_DEFAULT_THEME: Record<CapsuleType, CapsuleTheme> = {
  letter: "letter",
  memory: "polaroid",
  goal: "minimal",
  photos: "polaroid",
  video: "film",
  voice: "diary",
  song: "film",
  custom: "scrapbook",
};

const LOCK_OPTIONS: { key: LockType; emoji: string; label: string; hint: string }[] = [
  { key: "date", emoji: "📅", label: "Specific date", hint: "Opens on a day you choose" },
  { key: "days", emoji: "⏳", label: "After X days", hint: "A countdown from today" },
  { key: "birthday", emoji: "🎂", label: "Birthday", hint: "Reveals on your birthday" },
  { key: "new_year", emoji: "🎆", label: "New Year", hint: "January 1st" },
  { key: "event", emoji: "🎓", label: "Custom event", hint: "Graduation, trip, exam…" },
  { key: "surprise", emoji: "🎁", label: "Surprise me", hint: "Open on a bad day, no date" },
];

const STEPS = ["Type", "Content", "Lock", "Seal"];

export function CreateView({
  onBack,
  onCreated,
}: {
  onBack: () => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  const { create } = useCapsuleMutations();

  const [step, setStep] = useState(0);
  const [type, setType] = useState<CapsuleType | null>(null);

  // content fields
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [message, setMessage] = useState("");
  const [mood, setMood] = useState("");
  const [location, setLocation] = useState("");
  const [tags, setTags] = useState("");
  const [photos, setPhotos] = useState<MediaItem[]>([]);
  const [voice, setVoice] = useState<MediaItem | null>(null);
  const [video, setVideo] = useState<MediaItem | null>(null);
  const [song, setSong] = useState<MediaItem | null>(null);

  // lock fields
  const [lockType, setLockType] = useState<LockType>("date");
  const [lockDate, setLockDate] = useState("");
  const [lockTime, setLockTime] = useState("09:00");
  const [unlockDays, setUnlockDays] = useState(30);
  const [birthday, setBirthday] = useState("2000-01-01");
  const [lockLabel, setLockLabel] = useState("");
  const [recurring, setRecurring] = useState(false);

  // seal fields
  const [theme, setTheme] = useState<CapsuleTheme>("letter");
  const [sealing, setSealing] = useState(false);
  const successRef = useRef(false);
  const animDoneRef = useRef(false);

  const todayStr = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);

  const previewUnlock = useMemo(() => {
    return computeUnlockDate(lockType, { date: lockDate, time: lockTime, days: unlockDays, birthday });
  }, [lockType, lockDate, lockTime, unlockDays, birthday]);

  const pickType = (t: CapsuleType) => {
    setType(t);
    setTheme(TYPE_DEFAULT_THEME[t]);
    if (t === "memory" && !title) setTitle("This is what my life looks like right now");
    if (t === "goal" && !title) setTitle("");
    if (t === "memory") {
      setLockType("days");
      setUnlockDays(365);
    }
    if (t === "goal") setLockType("date");
    setStep(1);
  };

  const contentValid = (() => {
    if (!type) return false;
    if (type === "goal") return title.trim().length > 0;
    if (type === "letter") return content.trim().length > 0;
    if (type === "photos") return photos.length > 0 || content.trim().length > 0;
    if (type === "video") return video !== null || content.trim().length > 0;
    if (type === "voice") return voice !== null || content.trim().length > 0;
    if (type === "song") return (song?.caption || song?.url || content.trim()) ? true : false;
    return true; // memory & custom can be text-only
  })();

  const lockValid = (() => {
    if (lockType === "surprise") return true;
    if (!previewUnlock) return false;
    if (lockType === "date" || lockType === "event") return lockDate !== "";
    if (lockType === "event") return lockLabel.trim() !== "";
    return true;
  })();

  const canContinue = step === 0 ? type !== null : step === 1 ? contentValid : step === 2 ? lockValid : title.trim() !== "";

  const buildPayload = () => ({
    type: type as string,
    title: title.trim(),
    content,
    message: message || undefined,
    mood: mood || undefined,
    location: location || undefined,
    tags: tags || undefined,
    theme,
    lockType,
    lockLabel: lockType === "event" ? lockLabel.trim() || undefined : undefined,
    lockDate: lockDate || undefined,
    lockTime: lockType === "date" || lockType === "event" ? lockTime : undefined,
    unlockDays: lockType === "days" ? unlockDays : undefined,
    birthday: lockType === "birthday" ? birthday : undefined,
    isSurprise: lockType === "surprise",
    recurring: recurring && (lockType === "birthday" || lockType === "new_year") ? "yearly" : undefined,
    media: [
      ...photos,
      ...(voice ? [voice] : []),
      ...(video ? [video] : []),
      ...(song && (song.url || song.caption) ? [song] : []),
    ],
  });

  const finishSeal = () => {
    setSealing(false);
    if (successRef.current) setStep(4);
  };

  const handleSeal = async () => {
    if (!title.trim()) {
      toast({ title: "Give your capsule a title", variant: "destructive" });
      return;
    }
    successRef.current = false;
    animDoneRef.current = false;
    setSealing(true);
    try {
      await create.mutateAsync(buildPayload());
      successRef.current = true;
      if (animDoneRef.current) setStep(4); // overlay already finished
    } catch (e) {
      setSealing(false);
      toast({
        title: e instanceof Error ? e.message : "Failed to seal the capsule",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-6">
      <EnvelopeOverlay mode={sealing ? "seal" : null} onDone={() => { animDoneRef.current = true; finishSeal(); }} />
      {/* header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={step === 0 ? onBack : () => setStep(step - 1)} aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <h1 className="font-serif text-xl font-semibold">Create Capsule</h1>
          <div className="mt-1 flex items-center gap-1.5" aria-label={`Step ${Math.min(step + 1, 4)} of 4`}>
            {STEPS.map((s, i) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-all ${
                  i <= Math.min(step, 3) ? "w-7 bg-primary" : "w-3 bg-muted"
                }`}
              />
            ))}
            <span className="ml-2 text-[11px] text-muted-foreground">
              {STEPS[Math.min(step, 3)]}
            </span>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* STEP 0 — TYPE */}
        {step === 0 && (
          <motion.div
            key="s0"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
            className="mt-7"
          >
            <h2 className="font-serif text-2xl font-semibold leading-snug">
              What do you want to leave for your future self?
            </h2>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {(Object.keys(TYPE_META) as CapsuleType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => pickType(t)}
                  className="group flex flex-col items-start gap-1.5 rounded-2xl border bg-card p-4 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md focus-visible:outline-ring"
                >
                  <span className="text-2xl" aria-hidden>{TYPE_META[t].emoji}</span>
                  <span className="font-serif text-[15px] font-semibold">{TYPE_META[t].label}</span>
                  <span className="text-xs text-muted-foreground">{TYPE_META[t].hint}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* STEP 1 — CONTENT */}
        {step === 1 && type && (
          <motion.div
            key="s1"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
            className="mt-6 space-y-5 pb-4"
          >
            {type === "letter" && (
              <>
                <h2 className="font-hand text-3xl text-primary">Dear Future Me,</h2>
                <Textarea
                  placeholder="Write everything you want to remember, promise, or confess…"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="ruled-paper min-h-48 rounded-xl font-serif text-[15px] leading-8"
                  rows={7}
                />
              </>
            )}

            {type === "memory" && (
              <>
                <div>
                  <p className="font-serif text-lg">{format(new Date(), "MMMM d, yyyy")}</p>
                  <p className="font-hand text-xl text-muted-foreground">“This is what my life looks like right now.”</p>
                </div>
                <PhotoInput photos={photos} onChange={setPhotos} />
                <Textarea
                  placeholder="A few words about this moment…"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-24"
                  rows={3}
                />
                <div>
                  <p className="mb-1.5 text-sm font-medium">Voice note (optional)</p>
                  <VoiceRecorder value={voice} onChange={setVoice} />
                </div>
                <div>
                  <p className="mb-1.5 text-sm font-medium">Soundtrack (optional)</p>
                  <SongInput value={song} onChange={setSong} />
                </div>
              </>
            )}

            {type === "goal" && (
              <>
                <div>
                  <h2 className="font-serif text-xl font-semibold">What do you want to achieve?</h2>
                  <Input
                    placeholder="e.g. Learn SQL"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="mt-2 h-11 font-serif text-lg"
                  />
                </div>
                <div>
                  <p className="mb-1.5 text-sm font-medium">Details / how you&apos;ll get there</p>
                  <Textarea
                    placeholder="Break it down: what, when, how much per day…"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={3}
                  />
                </div>
                <div>
                  <p className="mb-1.5 text-sm font-medium">Message to future me</p>
                  <Input
                    placeholder="Did we do it?"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                </div>
              </>
            )}

            {type === "photos" && (
              <>
                <h2 className="font-serif text-xl font-semibold">Freeze this moment 📸</h2>
                <PhotoInput photos={photos} onChange={setPhotos} />
                <Textarea
                  placeholder="Where were you? What was happening?"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={3}
                />
              </>
            )}

            {type === "video" && (
              <>
                <h2 className="font-serif text-xl font-semibold">Say it on camera 🎥</h2>
                <VideoInput value={video} onChange={setVideo} />
                <Textarea
                  placeholder="Anything to add alongside the video?"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={2}
                />
              </>
            )}

            {type === "voice" && (
              <>
                <h2 className="font-serif text-xl font-semibold">In your own voice 🎙️</h2>
                <VoiceRecorder value={voice} onChange={setVoice} />
                <Textarea
                  placeholder="Optional note to go with it…"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={2}
                />
              </>
            )}

            {type === "song" && (
              <>
                <h2 className="font-serif text-xl font-semibold">A soundtrack for later 🎵</h2>
                <SongInput value={song} onChange={setSong} />
                <Textarea
                  placeholder="Why this song? What does it remind you of?"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={3}
                />
              </>
            )}

            {(type === "memory" || type === "custom") && (
              <div>
                <p className="mb-1.5 text-sm font-medium">Title</p>
                <Input
                  placeholder={type === "memory" ? "This is what my life looks like right now" : "Give it a name…"}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
            )}
            {type === "custom" && (
              <>
                <Textarea
                  placeholder="Whatever future you should find… a quote, a screenshot, a secret plan."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={3}
                />
                <PhotoInput photos={photos} onChange={setPhotos} max={4} />
              </>
            )}

            {/* shared optional fields */}
            {type !== "goal" && (
              <>
                <div>
                  <p className="mb-1.5 text-sm font-medium">Mood</p>
                  <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Mood">
                    {MOODS.map((m) => (
                      <button
                        key={m}
                        type="button"
                        role="radio"
                        aria-checked={mood === m}
                        onClick={() => setMood(mood === m ? "" : m)}
                        className={`h-10 w-10 rounded-xl border text-lg transition-all ${
                          mood === m
                            ? "border-primary bg-primary/10 shadow-sm scale-105"
                            : "bg-card hover:border-primary/40"
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="mb-1.5 text-sm font-medium">Location</p>
                    <Input
                      placeholder="Where are you?"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                  </div>
                  <div>
                    <p className="mb-1.5 text-sm font-medium">Tags</p>
                    <Input
                      placeholder="family, summer…"
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                    />
                  </div>
                </div>
              </>
            )}

            <Button size="lg" className="w-full gap-2" onClick={() => setStep(2)} disabled={!contentValid}>
              Continue <ArrowRight className="h-4 w-4" />
            </Button>
          </motion.div>
        )}

        {/* STEP 2 — LOCK */}
        {step === 2 && (
          <motion.div
            key="s2"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
            className="mt-6 space-y-4 pb-4"
          >
            <h2 className="font-serif text-2xl font-semibold">When should it open?</h2>
            <div className="grid gap-2.5">
              {LOCK_OPTIONS.map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => {
                    setLockType(opt.key);
                    if (opt.key === "days" && type === "memory") setUnlockDays(365);
                  }}
                  className={`flex items-center gap-3 rounded-2xl border p-3.5 text-left transition-all ${
                    lockType === opt.key
                      ? "border-primary bg-primary/5 ring-1 ring-primary/40"
                      : "bg-card hover:border-primary/40"
                  }`}
                  role="radio"
                  aria-checked={lockType === opt.key}
                >
                  <span className="text-xl" aria-hidden>{opt.emoji}</span>
                  <span className="flex-1">
                    <span className="block font-serif text-[15px] font-semibold">{opt.label}</span>
                    <span className="block text-xs text-muted-foreground">{opt.hint}</span>
                  </span>
                  <span
                    className={`h-4 w-4 rounded-full border-2 ${
                      lockType === opt.key ? "border-primary bg-primary" : "border-muted-foreground/40"
                    }`}
                    aria-hidden
                  />
                </button>
              ))}
            </div>

            {/* lock detail inputs */}
            {lockType === "date" && (
              <div className="grid grid-cols-2 gap-3 rounded-2xl border bg-card p-4">
                <div>
                  <p className="mb-1.5 text-sm font-medium">📅 Date</p>
                  <Input type="date" min={todayStr} value={lockDate} onChange={(e) => setLockDate(e.target.value)} />
                </div>
                <div>
                  <p className="mb-1.5 text-sm font-medium">⏰ Time</p>
                  <Input type="time" value={lockTime} onChange={(e) => setLockTime(e.target.value)} />
                </div>
              </div>
            )}
            {lockType === "days" && (
              <div className="rounded-2xl border bg-card p-4">
                <p className="mb-2 text-sm font-medium">Opens in how many days?</p>
                <div className="flex flex-wrap gap-2">
                  {[7, 30, 60, 100, 365].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setUnlockDays(n)}
                      className={`rounded-full border px-4 py-1.5 text-sm transition-all ${
                        unlockDays === n ? "border-primary bg-primary text-primary-foreground" : "bg-background hover:border-primary/40"
                      }`}
                    >
                      {n >= 365 ? `${Math.round(n / 365)} year${n >= 730 ? "s" : ""}` : `${n} days`}
                    </button>
                  ))}
                  <input
                    type="number"
                    min={1}
                    value={unlockDays}
                    onChange={(e) => setUnlockDays(Math.max(1, Number(e.target.value) || 1))}
                    className="w-20 rounded-full border bg-background px-3 py-1.5 text-center text-sm tabular-nums"
                    aria-label="Custom number of days"
                  />
                </div>
              </div>
            )}
            {lockType === "birthday" && (
              <div className="space-y-3 rounded-2xl border bg-card p-4">
                <div>
                  <p className="mb-1.5 text-sm font-medium">🎂 Your birthday</p>
                  <Input
                    type="date"
                    value={birthday}
                    max={todayStr}
                    onChange={(e) => setBirthday(e.target.value)}
                  />
                  <p className="mt-1 text-xs text-muted-foreground">Only month & day are used — it opens on the next one.</p>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">🔁 Repeat every year</p>
                    <p className="text-xs text-muted-foreground">A new capsule seals itself after each opening.</p>
                  </div>
                  <Switch checked={recurring} onCheckedChange={setRecurring} aria-label="Repeat every year" />
                </div>
              </div>
            )}
            {lockType === "new_year" && (
              <div className="rounded-2xl border bg-card p-4 text-sm text-muted-foreground">
                🎆 This capsule will open on <strong className="text-foreground">January 1st</strong> — right when the year turns.
              </div>
            )}
            {lockType === "event" && (
              <div className="grid gap-3 rounded-2xl border bg-card p-4">
                <div>
                  <p className="mb-1.5 text-sm font-medium">What event?</p>
                  <Input placeholder="Graduation day, trip to Paris, final exam…" value={lockLabel} onChange={(e) => setLockLabel(e.target.value)} />
                </div>
                <div>
                  <p className="mb-1.5 text-sm font-medium">📅 When is it?</p>
                  <Input type="date" min={todayStr} value={lockDate} onChange={(e) => setLockDate(e.target.value)} />
                </div>
              </div>
            )}
            {lockType === "surprise" && (
              <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 dark:border-rose-900 dark:bg-rose-950/40">
                <p className="font-serif font-semibold">🎁 Surprise capsule</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  No date. Future you will unlock it only by pressing “I need this today” — for the hard days.
                </p>
              </div>
            )}

            {/* preview */}
            {lockType !== "surprise" && (
              <div className="flex items-center gap-2.5 rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-3.5">
                <Lock className="h-4 w-4 shrink-0 text-primary" aria-hidden />
                <p className="text-sm">
                  {previewUnlock ? (
                    <>
                      Will stay sealed until{" "}
                      <strong className="font-serif">{format(previewUnlock, "MMMM d, yyyy")}</strong>
                      {" · "}
                      {format(previewUnlock, "HH:mm")}
                    </>
                  ) : (
                    "Choose a date above"
                  )}
                </p>
              </div>
            )}
            {(lockType === "birthday" || lockType === "new_year") && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                Tip: enable “Repeat every year” to make it a ritual.
              </div>
            )}

            <Button size="lg" className="w-full gap-2" onClick={() => setStep(3)} disabled={!lockValid}>
              Continue <ArrowRight className="h-4 w-4" />
            </Button>
          </motion.div>
        )}

        {/* STEP 3 — THEME + TITLE + SEAL */}
        {step === 3 && (
          <motion.div
            key="s3"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
            className="mt-6 space-y-5 pb-4"
          >
            <div>
              <h2 className="font-serif text-2xl font-semibold">Open this when…</h2>
              <p className="mt-1 text-sm text-muted-foreground">Give your capsule a name future you will recognize.</p>
              <Input
                placeholder="Open this when you need a reminder"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-2.5 h-11 font-serif"
              />
            </div>

            <div>
              <h3 className="font-serif text-lg font-semibold">Capsule theme</h3>
              <p className="mt-0.5 text-sm text-muted-foreground">How should it feel when it opens?</p>
              <div className="mt-3 grid grid-cols-4 gap-2">
                {(Object.keys(THEME_META) as CapsuleTheme[]).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTheme(t)}
                    className={`overflow-hidden rounded-xl border-2 transition-all ${
                      theme === t ? "border-primary shadow-md" : "border-transparent hover:border-border"
                    }`}
                    aria-pressed={theme === t}
                  >
                    <div className={`flex h-12 items-end bg-gradient-to-br ${THEME_META[t].gradient} p-1.5`}>
                      <span className="text-[9px] font-medium text-black/50">{THEME_META[t].label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* summary */}
            <div className="rounded-2xl border bg-card p-4 text-sm">
              <p className="font-serif text-base font-semibold">{TYPE_META[type as CapsuleType].emoji} {title || "Untitled capsule"}</p>
              <ul className="mt-2 space-y-1 text-muted-foreground">
                <li>· Sealed on {format(new Date(), "MMMM d, yyyy")}</li>
                {lockType === "surprise" ? (
                  <li>· Opens only via “I need this today”</li>
                ) : (
                  previewUnlock && <li>· Opens {format(previewUnlock, "MMMM d, yyyy")} at {format(previewUnlock, "HH:mm")}</li>
                )}
                <li>· Theme: {THEME_META[theme].label}</li>
              </ul>
            </div>

            <Button
              size="lg"
              className="w-full gap-2 font-serif text-lg"
              onClick={handleSeal}
              disabled={create.isPending || !title.trim()}
            >
              {create.isPending ? (
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent" />
              ) : (
                <>🔒 Seal Capsule</>
              )}
            </Button>
            {create.isPending && <p className="text-center text-xs text-muted-foreground">Wax is melting…</p>}
          </motion.div>
        )}

        {/* STEP 4 — SEALED SUCCESS */}
        {step === 4 && (
          <motion.div
            key="s4"
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-10 text-center"
          >
            <div className="wax-seal mx-auto flex h-24 w-24 items-center justify-center rounded-full">
              <span className="font-serif text-2xl font-bold text-fuchsia-100/90">FM</span>
            </div>
            <h2 className="mt-5 font-serif text-2xl font-semibold">Capsule sealed!</h2>
            <p className="mt-1.5 font-hand text-xl text-muted-foreground">
              {lockType === "surprise"
                ? "Future you will find it when it matters."
                : previewUnlock
                  ? `See you on ${format(previewUnlock, "MMMM d, yyyy")}.`
                  : "See you when the day comes."}
            </p>
            <div className="mt-6 grid gap-2.5">
              <Button size="lg" onClick={onCreated}>Back to Home</Button>
              <Button size="lg" variant="outline" onClick={onBack}>Create another</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
