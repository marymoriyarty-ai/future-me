"use client";

import { useState } from "react";
import { Lock, Unlock, Gift, ChevronDown, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { isReadyToOpen, type CapsuleDTO } from "@/lib/capsules";
import { useNow } from "../hooks";
import { OpenedCardVisual, SealedCardVisual } from "../sealed-visual";

export function TimelineView({
  capsules,
  onOpenCapsule,
}: {
  capsules: CapsuleDTO[];
  onOpenCapsule: (c: CapsuleDTO) => void;
}) {
  useNow(30000);
  const [collapsed, setCollapsed] = useState<Set<number>>(new Set());

  const sorted = [...capsules].sort((a, b) => {
    const ax = a.unlockDate ? new Date(a.unlockDate).getTime() : new Date(a.createdAt).getTime();
    const bx = b.unlockDate ? new Date(b.unlockDate).getTime() : new Date(b.createdAt).getTime();
    return ax - bx;
  });

  // group by year of unlock date (or creation for surprises)
  const groups = new Map<number, CapsuleDTO[]>();
  for (const c of sorted) {
    const d = c.unlockDate ? new Date(c.unlockDate) : new Date(c.createdAt);
    const year = d.getFullYear();
    if (!groups.has(year)) groups.set(year, []);
    groups.get(year)!.push(c);
  }
  const years = Array.from(groups.keys()).sort((a, b) => a - b);

  const toggleYear = (year: number) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(year)) next.delete(year);
      else next.add(year);
      return next;
    });

  const now = Date.now();

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-7 sm:max-w-2xl lg:max-w-3xl">
      <h1 className="px-1 font-serif text-2xl font-semibold">Timeline</h1>
      <p className="mt-0.5 px-1 text-sm text-muted-foreground">
        Messages traveling across the years — from past you to future you.
      </p>

      {years.length === 0 && (
        <div className="mt-6 rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          Nothing on the timeline yet.
        </div>
      )}

      <div className="mt-4 space-y-6 pb-8">
        {years.map((year) => {
          const items = groups.get(year)!;
          const openedN = items.filter((c) => c.status === "opened").length;
          const lockedN = items.length - openedN;
          const pct = Math.round((openedN / items.length) * 100);
          const isCollapsed = collapsed.has(year);

          // index of the first future item — the "today" mark goes right before it
          const firstFutureIdx = items.findIndex(
            (c) => (c.unlockDate ? new Date(c.unlockDate).getTime() : new Date(c.createdAt).getTime()) > now
          );
          const showToday = firstFutureIdx > 0;

          return (
            <section key={year} aria-label={`Year ${year}`}>
              {/* interactive year header */}
              <button
                type="button"
                onClick={() => toggleYear(year)}
                aria-expanded={!isCollapsed}
                className="group flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left transition-colors hover:bg-card/70"
              >
                <span className="font-serif text-xl font-semibold transition-colors group-hover:text-primary">
                  {year}
                </span>
                <span
                  className="h-1.5 w-16 overflow-hidden rounded-full bg-muted"
                  role="img"
                  aria-label={`${pct}% opened`}
                >
                  <span
                    className="block h-full rounded-full bg-gradient-to-r from-cyan-400 via-violet-500 to-fuchsia-500 transition-[width] duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </span>
                <span className="flex items-center gap-2.5 text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1" aria-label={`${openedN} opened`}>
                    <Unlock className="h-3 w-3" aria-hidden />
                    {openedN}
                  </span>
                  <span className="inline-flex items-center gap-1" aria-label={`${lockedN} locked`}>
                    <Lock className="h-3 w-3" aria-hidden />
                    {lockedN}
                  </span>
                </span>
                <ChevronDown
                  className={`ml-auto h-4 w-4 text-muted-foreground transition-transform duration-300 ${
                    isCollapsed ? "-rotate-90" : ""
                  }`}
                  aria-hidden
                />
              </button>

              <AnimatePresence initial={false}>
                {!isCollapsed && (
                  <motion.div
                    key="items"
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="relative ml-3 pb-1 pl-7 pt-1 sm:ml-0 sm:pl-0">
                      {/* flowing time spine — left on mobile, center on sm+ */}
                      <div className="fm-line absolute bottom-2 left-[5px] top-2 sm:left-1/2 sm:-ml-px" aria-hidden />

                      {items.map((c, i) => {
                        const opened = c.status === "opened";
                        const ready = isReadyToOpen(c);
                        const fromRight = i % 2 === 1;

                        return (
                          <div key={c.id}>
                            {/* TODAY marker between past and future — crimson pulse on the spine */}
                            {showToday && i === firstFutureIdx && (
                              <motion.div
                                initial={{ opacity: 0 }}
                                whileInView={{ opacity: 1 }}
                                viewport={{ once: true }}
                                className="relative flex items-center gap-2 py-1.5"
                                aria-hidden
                              >
                                <span className="fm-ready-node-red absolute -left-7 h-3 w-3 rounded-full bg-fuchsia-500 sm:left-1/2 sm:-ml-1.5" />
                                <span className="text-[10px] font-semibold uppercase tracking-[0.25em] text-fuchsia-400">
                                  today
                                </span>
                                <span className="h-px flex-1 bg-gradient-to-r from-fuchsia-400/50 to-transparent" />
                              </motion.div>
                            )}

                            <motion.button
                              type="button"
                              onClick={() => onOpenCapsule(c)}
                              initial={{ opacity: 0, x: fromRight ? 48 : -48, y: 40 }}
                              whileInView={{ opacity: 1, x: 0, y: 0 }}
                              viewport={{ once: true, amount: 0.2 }}
                              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: (i % 2) * 0.07 }}
                              whileHover={{ y: opened ? -3 : -4 }}
                              whileTap={{ scale: 0.99 }}
                              className={`fm-card-hover group relative mb-4 block w-full rounded-2xl text-left focus-visible:outline-ring sm:w-[calc(50%-1.75rem)] ${
                                fromRight ? "sm:ml-auto" : "sm:mr-auto"
                              } ${!opened && ready ? "shadow-[0_0_28px_-6px] shadow-primary/50" : ""}`}
                            >
                              {/* node dot — rides the spine (centered on sm+) */}
                              <span
                                className={`absolute -left-8 top-5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-background transition-transform duration-300 group-hover:scale-125 sm:top-6 ${
                                  fromRight ? "sm:left-auto sm:right-[calc(100%+18px)]" : "sm:left-[calc(100%+18px)]"
                                } ${
                                  opened
                                    ? "bg-primary"
                                    : ready
                                      ? "fm-ready-node bg-amber-400"
                                      : "bg-muted-foreground/40"
                                }`}
                                aria-hidden
                              >
                                {opened ? (
                                  <Unlock className="h-2.5 w-2.5 text-primary-foreground" />
                                ) : ready ? (
                                  <Gift className="h-2.5 w-2.5 text-amber-950" />
                                ) : c.isSurprise ? (
                                  <Sparkles className="h-2.5 w-2.5 text-background" />
                                ) : (
                                  <Lock className="h-2.5 w-2.5 text-background" />
                                )}
                              </span>

                              {/* every capsule wears its type's form:
                                  locked = sealed shape + countdown, opened = opened shape */}
                              {!opened ? (
                                <SealedCardVisual capsule={c} />
                              ) : (
                                <OpenedCardVisual capsule={c} />
                              )}
                            </motion.button>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </section>
          );
        })}
      </div>
    </div>
  );
}
