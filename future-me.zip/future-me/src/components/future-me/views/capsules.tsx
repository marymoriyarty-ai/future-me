"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Lock, Unlock, Plus } from "lucide-react";
import { TYPE_META, isReadyToOpen, type CapsuleDTO } from "@/lib/capsules";
import { OpenedCardVisual, SealedCardVisual } from "../sealed-visual";
import { useNow } from "../hooks";
import { Skeleton } from "@/components/ui/skeleton";

const FILTERS = [
  { key: "all", label: "All", emoji: "✦" },
  { key: "letters", label: "Letters", emoji: "💌" },
  { key: "memories", label: "Memories", emoji: "📦" },
  { key: "goals", label: "Goals", emoji: "🎯" },
  { key: "media", label: "Media", emoji: "🎬" },
] as const;

function matchesFilter(c: CapsuleDTO, filter: string): boolean {
  switch (filter) {
    case "letters":
      return c.type === "letter";
    case "memories":
      return c.type === "memory";
    case "goals":
      return c.type === "goal";
    case "media":
      return ["photos", "video", "voice", "song"].includes(c.type);
    default:
      return true;
  }
}

/* ---------- archive card: richer than the home capsule card ---------- */

function ArchiveCard({
  capsule,
  onOpen,
  index = 0,
}: {
  capsule: CapsuleDTO;
  onOpen: (c: CapsuleDTO) => void;
  index?: number;
}) {
  useNow(30000);
  const opened = capsule.status === "opened";
  const ready = isReadyToOpen(capsule);

  const badges = (
    <div className="absolute right-2.5 top-2.5 z-20 flex items-center gap-1">
      <span
        className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
        aria-hidden
      >
        {TYPE_META[capsule.type]?.emoji || "✨"}
      </span>
      {capsule.isSurprise && (
        <span
          className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
          aria-hidden
        >
          🎁
        </span>
      )}
      {capsule.recurring === "yearly" && (
        <span
          className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
          aria-hidden
        >
          🔁
        </span>
      )}
    </div>
  );

  /* ---- LOCKED: the whole card IS the capsule's own type,
          with the countdown living inside the shape ---- */
  if (!opened) {
    return (
      <motion.button
        type="button"
        onClick={() => onOpen(capsule)}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: Math.min(index * 0.04, 0.35), duration: 0.35 }}
        whileHover={{ y: -4 }}
        whileTap={{ scale: 0.985 }}
        className={`fm-card-hover group relative block w-full rounded-2xl text-left focus-visible:outline-ring ${
          ready ? "shadow-[0_0_28px_-6px] shadow-primary/50" : ""
        }`}
        aria-label={`Capsule: ${capsule.title}`}
      >
        {badges}
        <SealedCardVisual capsule={capsule} />
      </motion.button>
    );
  }

  /* ---- OPENED: the same form, caught in its opened state ---- */
  return (
    <motion.button
      type="button"
      onClick={() => onOpen(capsule)}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.04, 0.35), duration: 0.35 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.985 }}
      className="fm-card-hover group relative block w-full rounded-2xl text-left focus-visible:outline-ring"
      aria-label={`Capsule: ${capsule.title}`}
    >
      {badges}
      <OpenedCardVisual capsule={capsule} />
    </motion.button>
  );
}

/* ---------- the archive view ---------- */

export function CapsulesView({
  capsules,
  isLoading,
  onOpenCapsule,
  onCreate,
}: {
  capsules: CapsuleDTO[];
  isLoading: boolean;
  onOpenCapsule: (c: CapsuleDTO) => void;
  onCreate?: () => void;
}) {
  const [tab, setTab] = useState<"locked" | "opened">("locked");
  const [filter, setFilter] = useState<string>("all");

  const lockedN = capsules.filter((c) => c.status === "locked").length;
  const openedN = capsules.length - lockedN;

  const tabList = capsules.filter((c) => (tab === "opened" ? c.status === "opened" : c.status === "locked"));

  const list = tabList
    .filter((c) => matchesFilter(c, filter))
    .sort((a, b) => {
      if (tab === "opened") {
        return new Date(b.openedAt || 0).getTime() - new Date(a.openedAt || 0).getTime();
      }
      const ax = a.unlockDate ? new Date(a.unlockDate).getTime() : Number.MAX_SAFE_INTEGER;
      const bx = b.unlockDate ? new Date(b.unlockDate).getTime() : Number.MAX_SAFE_INTEGER;
      return ax - bx;
    });

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-7 sm:max-w-2xl lg:max-w-3xl">
      {/* header with live counts */}
      <div className="flex flex-wrap items-end justify-between gap-2 px-1">
        <div>
          <h1 className="font-serif text-2xl font-semibold">My Capsules</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">Your personal archive, sealed and unsealed.</p>
        </div>
        <div className="flex items-center gap-1.5 pb-0.5 text-[11px] font-medium">
          <span className="inline-flex items-center gap-1 rounded-full border bg-card/80 px-2.5 py-1 text-muted-foreground">
            <Lock className="h-3 w-3" aria-hidden /> {lockedN} sealed
          </span>
          <span className="inline-flex items-center gap-1 rounded-full border bg-card/80 px-2.5 py-1 text-muted-foreground">
            <Unlock className="h-3 w-3" aria-hidden /> {openedN} opened
          </span>
        </div>
      </div>

      {/* segmented tab with sliding pill */}
      <div className="mt-4 grid grid-cols-2 rounded-2xl border bg-card/80 p-1 backdrop-blur-sm" role="tablist" aria-label="Locked or opened">
        {(
          [
            { key: "locked", label: "Locked", icon: Lock, count: lockedN },
            { key: "opened", label: "Opened", icon: Unlock, count: openedN },
          ] as const
        ).map(({ key, label, icon: Icon, count }) => {
          const active = tab === key;
          return (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setTab(key)}
              className="relative rounded-xl py-2 text-sm font-medium"
            >
              {active && (
                <motion.span
                  layoutId="capsule-tab-pill"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  className="absolute inset-0 rounded-xl bg-gradient-to-r from-indigo-600 to-fuchsia-600 shadow-md shadow-fuchsia-500/25"
                />
              )}
              <span
                className={`relative z-10 flex items-center justify-center gap-1.5 transition-colors ${
                  active ? "text-white" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden /> {label}
                <span
                  className={`rounded-full px-1.5 text-[10px] font-semibold tabular-nums ${
                    active ? "bg-white/20" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {count}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      {/* type filters with emoji + live counts */}
      <div className="fm-scroll mt-3 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Filter by type">
        {FILTERS.map((f) => {
          const count = tabList.filter((c) => matchesFilter(c, f.key)).length;
          const active = filter === f.key;
          return (
            <button
              key={f.key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setFilter(f.key)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm transition-all ${
                active
                  ? "border-fuchsia-400/40 bg-gradient-to-r from-indigo-600 to-fuchsia-600 text-white shadow-md shadow-fuchsia-500/25"
                  : "bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
              }`}
            >
              <span aria-hidden>{f.emoji}</span>
              {f.label}
              <span
                className={`rounded-full px-1.5 text-[10px] font-semibold tabular-nums ${
                  active ? "bg-white/20" : "bg-muted"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* the archive grid */}
      <div key={`${tab}-${filter}`} className="mt-4 grid items-start gap-4 pb-6 sm:grid-cols-2 sm:gap-5">
        {isLoading && (
          <>
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-36 w-full rounded-2xl" />
            ))}
          </>
        )}
        {!isLoading && list.length === 0 && (
          <div className="col-span-full rounded-2xl border border-dashed p-8 text-center">
            <p className="text-3xl" aria-hidden>
              {tab === "locked" ? "🔒" : "🔓"}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              {tab === "locked"
                ? "No locked capsules here yet — create one for future you."
                : "Nothing opened yet. The first one will land here."}
            </p>
            {tab === "locked" && onCreate && (
              <button
                type="button"
                onClick={onCreate}
                className="mx-auto mt-4 flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-fuchsia-600 px-4 py-2 text-sm font-medium text-white shadow-md shadow-fuchsia-500/25 transition-transform hover:scale-[1.03]"
              >
                <Plus className="h-4 w-4" aria-hidden /> Create a capsule
              </button>
            )}
          </div>
        )}
        {list.map((c, i) => (
          <ArchiveCard key={c.id} capsule={c} onOpen={onOpenCapsule} index={i} />
        ))}
      </div>
    </div>
  );
}
