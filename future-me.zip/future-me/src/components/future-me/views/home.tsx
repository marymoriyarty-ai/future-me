"use client";

import { motion } from "framer-motion";
import { Plus, Gift, Clock3, Lock, Unlock } from "lucide-react";
import { type CapsuleDTO } from "@/lib/capsules";
import { CapsuleCard } from "../capsule-card";
import { Skeleton } from "@/components/ui/skeleton";

export function HomeView({
  capsules,
  isLoading,
  onOpenCapsule,
  onCreate,
}: {
  capsules: CapsuleDTO[];
  isLoading: boolean;
  onOpenCapsule: (c: CapsuleDTO) => void;
  onCreate: () => void;
}) {
  const now = Date.now();
  const ready = capsules.filter(
    (c) => c.status === "locked" && !c.isSurprise && c.unlockDate && new Date(c.unlockDate).getTime() <= now
  );
  // Upcoming = only the nearest sealed capsules, at most one month ahead
  const MONTH_MS = 30 * 24 * 60 * 60 * 1000;
  const soon = capsules
    .filter((c) => c.status === "locked" && c.unlockDate)
    .map((c) => ({ c, t: new Date(c.unlockDate!).getTime() }))
    .filter(({ t }) => t > now && t <= now + MONTH_MS)
    .sort((a, b) => a.t - b.t);
  const upcoming = soon.slice(0, 4).map(({ c }) => c);
  const laterCount = capsules.filter((c) => {
    if (c.status !== "locked" || !c.unlockDate) return false;
    return new Date(c.unlockDate).getTime() > now + MONTH_MS;
  }).length;
  const openedCount = capsules.filter((c) => c.status === "opened").length;
  const lockedCount = capsules.length - openedCount;

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-8 sm:max-w-2xl lg:max-w-3xl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="text-center"
      >
        <div className="fm-float mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500/90 via-violet-600/90 to-fuchsia-600/90 text-3xl shadow-lg shadow-primary/40 dark:from-indigo-600 dark:via-violet-700 dark:to-fuchsia-900">
          🪐
        </div>
        <h1 className="font-serif text-3xl font-semibold tracking-tight">Future Me</h1>
        <p className="mt-1.5 font-hand text-xl text-muted-foreground">
          Leave something for your future self.
        </p>
      </motion.div>

      {/* Create CTA — pinned to the top of the page */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mt-5"
      >
        <motion.button
          type="button"
          onClick={onCreate}
          whileHover={{ scale: 1.015 }}
          whileTap={{ scale: 0.98 }}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-500 font-serif text-lg font-semibold text-white shadow-lg shadow-fuchsia-500/30 transition-shadow hover:shadow-fuchsia-500/45"
        >
          <Plus className="h-5 w-5" aria-hidden /> Create Capsule
        </motion.button>
      </motion.div>

      {/* Ready banner */}
      {ready.length > 0 && (
        <motion.button
          type="button"
          onClick={() => onOpenCapsule(ready[0])}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          className="mt-6 flex w-full items-center gap-3 rounded-2xl border border-primary/50 bg-gradient-to-r from-indigo-950/70 via-violet-950/50 to-fuchsia-950/40 p-4 text-left shadow-lg shadow-primary/10"
        >
          <div className="wax-seal fm-glow-pulse flex h-11 w-11 shrink-0 items-center justify-center rounded-full">
            <Gift className="h-5 w-5 text-fuchsia-100" aria-hidden />
          </div>
          <div className="min-w-0">
            <p className="fm-shimmer font-serif text-[15px] font-semibold">
              You have something from your past self.
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {ready.length === 1
                ? `“${ready[0].title}” is ready to open`
                : `${ready.length} capsules are ready to open`}
            </p>
          </div>
          <span className="ml-auto shrink-0 font-hand text-lg text-primary">open →</span>
        </motion.button>
      )}

      {/* Quick stats — aligned at the top */}
      <section className="mt-7 grid grid-cols-3 gap-3" aria-label="Quick stats">
        {[
          { icon: Lock, label: "Sealed", value: lockedCount },
          { icon: Unlock, label: "Opened", value: openedCount },
          { icon: Gift, label: "Total", value: capsules.length },
        ].map(({ icon: Icon, label, value }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.06 }}
            className="fm-card-hover rounded-2xl border bg-card/80 p-3.5 text-center shadow-sm backdrop-blur-sm"
          >
            <Icon className="mx-auto h-4 w-4 text-primary/70" aria-hidden />
            <div className="mt-1 font-serif text-2xl font-semibold tabular-nums">{value}</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
          </motion.div>
        ))}
      </section>

      {/* Upcoming — full width, shaped capsules in a grid */}
      <section className="mt-7" aria-labelledby="upcoming-heading">
        <div className="flex items-center justify-between px-1">
          <h2
            id="upcoming-heading"
            className="flex items-center gap-1.5 text-sm font-semibold uppercase tracking-wider text-muted-foreground"
          >
            <Clock3 className="h-3.5 w-3.5 text-primary/70" aria-hidden /> Upcoming
          </h2>
          {upcoming.length > 0 && (
            <span className="text-xs text-muted-foreground">{upcoming.length} sealed</span>
          )}
        </div>

        <div className="mt-3 grid grid-cols-1 items-start gap-4 sm:grid-cols-2 sm:gap-5">
          {isLoading && (
            <>
              <Skeleton className="h-44 w-full rounded-2xl" />
              <Skeleton className="h-44 w-full rounded-2xl" />
            </>
          )}
          {!isLoading && upcoming.length === 0 && ready.length === 0 && (
            <div className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground sm:col-span-2">
              Nothing unlocking within a month. Time to leave a message for future you.
            </div>
          )}
          {upcoming.map((c, i) => (
            <CapsuleCard key={c.id} capsule={c} onOpen={onOpenCapsule} index={i} />
          ))}
          {laterCount > 0 && (
            <p className="px-1 pt-1 text-center font-hand text-lg text-muted-foreground/70 sm:col-span-2">
              +{laterCount} more sleeping further ahead…
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
