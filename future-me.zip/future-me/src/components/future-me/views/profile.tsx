"use client";

import { useTheme } from "next-themes";
import { format } from "date-fns";
import { Moon, Sun, Laptop, Heart } from "lucide-react";
import { useState } from "react";
import { TYPE_META, timeRemaining, type CapsuleDTO, type CapsuleType } from "@/lib/capsules";
import { useNow } from "../hooks";
import { useToast } from "@/hooks/use-toast";

export function ProfileView({ capsules }: { capsules: CapsuleDTO[] }) {
  useNow(60000);
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  const now = Date.now();
  const locked = capsules.filter((c) => c.status === "locked");
  const opened = capsules.filter((c) => c.status === "opened");
  const next = locked
    .filter((c) => c.unlockDate && new Date(c.unlockDate).getTime() > now)
    .sort((a, b) => new Date(a.unlockDate!).getTime() - new Date(b.unlockDate!).getTime())[0];
  const longestWait = locked.reduce((max, c) => {
    if (!c.unlockDate) return max;
    const days = Math.ceil((new Date(c.unlockDate).getTime() - new Date(c.createdAt).getTime()) / 86400000);
    return Math.max(max, days);
  }, 0);

  const byType = (Object.keys(TYPE_META) as CapsuleType[]).map((t) => ({
    type: t,
    count: capsules.filter((c) => c.type === t).length,
  })).filter((x) => x.count > 0);

  const surprisesOpened = opened.filter((c) => c.isSurprise).length;
  const goalsAchieved = opened.filter((c) => c.type === "goal" && c.goalOutcome === "yes").length;

  const themeOptions = [
    { key: "light", icon: Sun, label: "Light" },
    { key: "dark", icon: Moon, label: "Dark" },
    { key: "system", icon: Laptop, label: "Auto" },
  ];

  return (
    <div className="mx-auto w-full max-w-lg px-4 pt-7 pb-8">
      <h1 className="px-1 font-serif text-2xl font-semibold">Profile</h1>
      <p className="mt-0.5 px-1 text-sm text-muted-foreground">Your time-travel record so far.</p>

      {/* hero stats */}
      <div className="mt-5 rounded-3xl border bg-gradient-to-br from-indigo-100 via-violet-50 to-cyan-50 p-6 text-center shadow-sm dark:from-indigo-950/50 dark:via-violet-950/40 dark:to-cyan-950/30">
        <div className="font-hand text-xl text-muted-foreground">you are carrying</div>
        <div className="mt-1 font-serif text-5xl font-semibold tabular-nums">{locked.length}</div>
        <div className="text-sm uppercase tracking-[0.25em] text-muted-foreground">sealed capsules</div>
        {next?.unlockDate && (
          <p className="mt-3 text-sm text-muted-foreground">
            next one opens{" "}
            <strong className="text-foreground">{format(new Date(next.unlockDate), "MMM d, yyyy")}</strong> (
            {timeRemaining(next.unlockDate).days > 0
              ? `${timeRemaining(next.unlockDate).days} days`
              : `${timeRemaining(next.unlockDate).hours} hours`}{" "}
            to go)
          </p>
        )}
      </div>

      {/* stats grid */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        {[
          { label: "Opened capsules", value: opened.length, emoji: "🔓" },
          { label: "Longest wait", value: `${longestWait} d`, emoji: "⏳" },
          { label: "Goals achieved", value: goalsAchieved, emoji: "🎯" },
          { label: "Bad days saved", value: surprisesOpened, emoji: "🤍" },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border bg-card p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="font-serif text-2xl font-semibold tabular-nums">{s.value}</span>
              <span className="text-lg" aria-hidden>{s.emoji}</span>
            </div>
            <div className="mt-0.5 text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      {/* by type */}
      {byType.length > 0 && (
        <div className="mt-4 rounded-2xl border bg-card p-5 shadow-sm">
          <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">By type</p>
          <div className="mt-3 space-y-2.5">
            {byType.map(({ type, count }) => {
              const pct = Math.round((count / Math.max(1, capsules.length)) * 100);
              return (
                <div key={type} className="flex items-center gap-3">
                  <span className="w-6 text-center" aria-hidden>{TYPE_META[type].emoji}</span>
                  <span className="w-24 shrink-0 text-xs font-medium">{TYPE_META[type].label}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary/70" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-6 text-right text-xs tabular-nums text-muted-foreground">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* settings */}
      <div className="mt-4 rounded-2xl border bg-card p-5 shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Appearance</p>
        <div className="mt-3 flex gap-2">
          {themeOptions.map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              type="button"
              onClick={() => setTheme(key)}
              className={`flex flex-1 flex-col items-center gap-1 rounded-xl border py-3 text-xs font-medium transition-all ${
                theme === key
                  ? "border-primary bg-primary/10 text-primary"
                  : "hover:border-primary/40 text-muted-foreground"
              }`}
              aria-pressed={theme === key}
            >
              <Icon className="h-4 w-4" aria-hidden />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* about */}
      <div className="mt-4 rounded-2xl border bg-card p-5 text-center shadow-sm">
        <div className="text-2xl" aria-hidden>🕰️</div>
        <p className="mt-1 font-serif text-base font-semibold">Future Me</p>
        <p className="mx-auto mt-1 max-w-xs text-xs leading-5 text-muted-foreground">
          A little time machine for everyday life. Write now, feel later — everything you seal
          here is a gift waiting for the right day.
        </p>
        <p className="mt-3 flex items-center justify-center gap-1 text-[11px] text-muted-foreground">
          made with <Heart className="h-3 w-3 text-fuchsia-400" aria-hidden /> for your future self
        </p>
      </div>
    </div>
  );
}
