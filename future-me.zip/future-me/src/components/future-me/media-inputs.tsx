"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mic, Square, ImageIcon, Trash2, Upload, Music, Video } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export interface MediaItem {
  kind: "photo" | "video" | "voice" | "song";
  url: string;
  caption?: string;
}

/** Downscale an image file to keep data URLs light. */
async function fileToDataUrl(file: File, maxDim = 1200, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read the file"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Could not load the image"));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export function PhotoInput({
  photos,
  onChange,
  max = 8,
}: {
  photos: MediaItem[];
  onChange: (items: MediaItem[]) => void;
  max?: number;
}) {
  const { toast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const handleFiles = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      setBusy(true);
      try {
        const room = max - photos.length;
        const picked = Array.from(files).slice(0, Math.max(0, room));
        const converted: MediaItem[] = [];
        for (const f of picked) {
          if (!f.type.startsWith("image/")) continue;
          if (f.size > 15 * 1024 * 1024) {
            toast({ title: "Image too large (max 15 MB)", variant: "destructive" });
            continue;
          }
          const url = await fileToDataUrl(f);
          converted.push({ kind: "photo", url, caption: "" });
        }
        if (converted.length) onChange([...photos, ...converted]);
        if (files.length > picked.length) {
          toast({ title: `Only ${max} photos fit in this capsule` });
        }
      } catch {
        toast({ title: "Could not add photos", variant: "destructive" });
      } finally {
        setBusy(false);
        if (inputRef.current) inputRef.current.value = "";
      }
    },
    [photos, max, onChange, toast]
  );

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
        aria-label="Add photos"
      />
      <div className="grid grid-cols-3 gap-2">
        {photos.map((p, i) => (
          <div key={i} className="group relative aspect-square overflow-hidden rounded-xl border bg-muted">
            <img src={p.url} alt={p.caption || "Capsule photo"} className="h-full w-full object-cover" />
            <button
              type="button"
              onClick={() => onChange(photos.filter((_, j) => j !== i))}
              className="absolute right-1.5 top-1.5 rounded-full bg-black/55 p-1.5 text-white opacity-0 transition-opacity group-hover:opacity-100 focus:opacity-100"
              aria-label="Remove photo"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
        {photos.length < max && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={busy}
            className="flex aspect-square flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-border text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary disabled:opacity-50"
            aria-label="Upload photo"
          >
            {busy ? (
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent" />
            ) : (
              <>
                <ImageIcon className="h-5 w-5" aria-hidden />
                <span className="text-[11px] font-medium">Add photo</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

export function VoiceRecorder({ value, onChange }: { value: MediaItem | null; onChange: (m: MediaItem | null) => void }) {
  const { toast } = useToast();
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      recorderRef.current?.stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        if (blob.size > 8 * 1024 * 1024) {
          toast({ title: "Recording too long (max ~8 MB)", variant: "destructive" });
        } else {
          const reader = new FileReader();
          reader.onload = () => onChange({ kind: "voice", url: String(reader.result), caption: "" });
          reader.readAsDataURL(blob);
        }
        stream.getTracks().forEach((t) => t.stop());
      };
      rec.start();
      recorderRef.current = rec;
      setRecording(true);
      setSeconds(0);
      timerRef.current = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    } catch {
      toast({
        title: "Microphone unavailable",
        description: "You can upload an audio file instead.",
        variant: "destructive",
      });
    }
  };

  const stop = () => {
    recorderRef.current?.stop();
    recorderRef.current = null;
    setRecording(false);
    if (timerRef.current) window.clearInterval(timerRef.current);
  };

  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="flex items-center gap-3">
        {!recording ? (
          <Button type="button" onClick={start} variant="outline" className="gap-2">
            <Mic className="h-4 w-4" aria-hidden /> Record voice
          </Button>
        ) : (
          <Button type="button" onClick={stop} variant="destructive" className="gap-2">
            <Square className="h-4 w-4" aria-hidden /> Stop ({seconds}s)
          </Button>
        )}
        {recording && (
          <div className="flex items-center gap-1" aria-hidden>
            {[0, 1, 2, 3, 4].map((i) => (
              <span
                key={i}
                className="w-1 rounded-full bg-primary/70 animate-pulse"
                style={{ height: `${8 + ((seconds + i) % 3) * 6}px`, animationDelay: `${i * 120}ms` }}
              />
            ))}
          </div>
        )}
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="ml-auto gap-1.5 text-muted-foreground"
          onClick={() => fileRef.current?.click()}
        >
          <Upload className="h-3.5 w-3.5" aria-hidden /> Upload audio
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            if (f.size > 8 * 1024 * 1024) {
              toast({ title: "Audio too large (max 8 MB)", variant: "destructive" });
              return;
            }
            const reader = new FileReader();
            reader.onload = () => onChange({ kind: "voice", url: String(reader.result), caption: f.name });
            reader.readAsDataURL(f);
            e.target.value = "";
          }}
          aria-label="Upload audio file"
        />
      </div>
      {value && (
        <div className="mt-3 flex items-center gap-2 rounded-lg bg-muted/60 p-2.5">
          <audio controls src={value.url} className="h-9 w-full" />
          <button
            type="button"
            onClick={() => onChange(null)}
            className="shrink-0 rounded-full p-1.5 text-muted-foreground hover:bg-background hover:text-destructive"
            aria-label="Remove recording"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}

export function VideoInput({ value, onChange }: { value: MediaItem | null; onChange: (m: MediaItem | null) => void }) {
  const { toast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          if (f.size > 10 * 1024 * 1024) {
            toast({ title: "Video too large (max 10 MB in this demo)", variant: "destructive" });
            return;
          }
          const reader = new FileReader();
          reader.onload = () => onChange({ kind: "video", url: String(reader.result), caption: f.name });
          reader.readAsDataURL(f);
          e.target.value = "";
        }}
        aria-label="Upload video"
      />
      {!value ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border py-8 text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary"
        >
          <Video className="h-6 w-6" aria-hidden />
          <span className="text-sm font-medium">Upload a short video (max 10 MB)</span>
        </button>
      ) : (
        <div className="relative overflow-hidden rounded-xl border">
          <video controls src={value.url} className="max-h-64 w-full bg-black" />
          <button
            type="button"
            onClick={() => onChange(null)}
            className="absolute right-2 top-2 rounded-full bg-black/60 p-1.5 text-white"
            aria-label="Remove video"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}

export function SongInput({
  value,
  onChange,
}: {
  value: MediaItem | null;
  onChange: (m: MediaItem | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 rounded-xl border bg-card p-3">
        <Music className="h-4 w-4 text-muted-foreground" aria-hidden />
        <Input
          placeholder="Song title & artist — e.g. 'Golden Hour — JVKE'"
          value={value?.caption || ""}
          onChange={(e) =>
            onChange({
              kind: "song",
              url: value?.url || "",
              caption: e.target.value,
            })
          }
          className="border-0 bg-transparent shadow-none focus-visible:ring-0"
          aria-label="Song title and artist"
        />
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="audio/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          if (f.size > 8 * 1024 * 1024) {
            toast({ title: "Audio too large (max 8 MB)", variant: "destructive" });
            return;
          }
          const reader = new FileReader();
          reader.onload = () =>
            onChange({ kind: "song", url: String(reader.result), caption: value?.caption || f.name });
          reader.readAsDataURL(f);
          e.target.value = "";
        }}
        aria-label="Upload song file"
      />
      <div className="flex items-center gap-3">
        <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => inputRef.current?.click()}>
          <Upload className="h-3.5 w-3.5" aria-hidden /> Attach audio file (optional)
        </Button>
        {value?.url && (
          <button
            type="button"
            onClick={() => onChange({ kind: "song", url: "", caption: value.caption })}
            className="text-xs text-muted-foreground underline hover:text-destructive"
          >
            remove file
          </button>
        )}
      </div>
      {value?.url && <audio controls src={value.url} className="w-full" />}
    </div>
  );
}
