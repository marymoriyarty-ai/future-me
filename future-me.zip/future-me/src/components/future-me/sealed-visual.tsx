"use client";

import { format } from "date-fns";
import { Aperture, Gift, Heart, Lock, Mic, Play, Sparkles, Sun, Target, Unlock } from "lucide-react";
import { isReadyToOpen, timeRemaining, type CapsuleDTO, type CapsuleType } from "@/lib/capsules";
import { CountdownHero } from "./countdown";
import { useNow } from "./hooks";

/* ------------------------------------------------------------------ */
/* status bits shared by every shaped visual                           */
/* ------------------------------------------------------------------ */

/** Tiny countdown chips that live INSIDE the shaped visuals. */
function ShapeCountdown({ target, ink = false }: { target: string; ink?: boolean }) {
  useNow(15000);
  const r = timeRemaining(target);
  if (r.total <= 0) {
    return (
      <span className={`text-[11px] font-semibold ${ink ? "text-violet-700" : "text-primary"}`}>
        ready to open!
      </span>
    );
  }
  const parts: Array<[number, string]> =
    r.days > 0
      ? [
          [r.days, "d"],
          [r.hours, "h"],
          [r.minutes, "m"],
        ]
      : [
          [r.hours, "h"],
          [r.minutes, "m"],
        ];
  return (
    <span className={`inline-flex items-center gap-1 ${ink ? "text-zinc-800" : "text-zinc-100"}`}>
      {parts.map(([v, l]) => (
        <span
          key={l}
          className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold tabular-nums ${
            ink ? "bg-zinc-900/10" : "bg-white/10"
          }`}
        >
          {v}
          <span className="ml-0.5 opacity-70">{l}</span>
        </span>
      ))}
    </span>
  );
}

/** Ready / rainy-day / countdown — the one status line every shape shows. */
function StatusRow({ capsule, ink = false }: { capsule: CapsuleDTO; ink?: boolean }) {
  const base = `flex items-center gap-1.5 text-[11px] font-medium ${ink ? "text-zinc-700" : "text-zinc-200"}`;
  if (isReadyToOpen(capsule)) {
    return (
      <span className={`${base} text-primary`}>
        <Gift className="h-3.5 w-3.5" aria-hidden /> Ready to open!
      </span>
    );
  }
  if (capsule.isSurprise && !capsule.unlockDate) {
    return (
      <span className={base}>
        <Sparkles className="h-3.5 w-3.5 text-fuchsia-300" aria-hidden /> for a rainy day
      </span>
    );
  }
  if (capsule.unlockDate) return <ShapeCountdown target={capsule.unlockDate} ink={ink} />;
  return (
    <span className={base}>
      <Lock className="h-3 w-3" aria-hidden /> sealed
    </span>
  );
}

/** Hand-written “opens on …” line, styled per surface. */
function OpensLine({ capsule, tone = "light" }: { capsule: CapsuleDTO; tone?: "light" | "ink" }) {
  if (!capsule.unlockDate) return null;
  return (
    <span className={`font-hand text-sm ${tone === "ink" ? "text-zinc-600" : "text-cyan-200/80"}`}>
      opens {format(new Date(capsule.unlockDate), "MMM d, yyyy")}
    </span>
  );
}

/**
 * The status element for a shape. In hero mode (detail page) a locked capsule
 * with a date gets the big CountdownHero — the countdown literally lives
 * inside the shape. Otherwise the compact chips.
 */
function ShapeStatus({
  capsule,
  hero = false,
  tone = "light",
  size = "sm",
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  tone?: "light" | "ink";
  size?: "lg" | "sm";
}) {
  if (hero && capsule.unlockDate) {
    const r = timeRemaining(capsule.unlockDate);
    if (r.total > 0) return <CountdownHero target={capsule.unlockDate} tone={tone} size={size} />;
  }
  return <StatusRow capsule={capsule} ink={tone === "ink"} />;
}

/* ------------------------------------------------------------------ */
/* the eight type-shaped sealed visuals — each one IS the capsule      */
/* ------------------------------------------------------------------ */

/* ---- LETTER · a sealed envelope ---------------------------------- */
function EnvelopeShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-indigo-300/30 bg-gradient-to-br from-indigo-950 via-violet-950 to-fuchsia-950 shadow-lg shadow-black/30 ${
        hero ? "flex min-h-[290px] flex-col" : "flex min-h-[168px] flex-col"
      }`}
    >
      {/* envelope flap */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[58%] border-b border-white/10 bg-gradient-to-b from-white/[0.13] to-transparent [clip-path:polygon(0_0,100%_0,50%_100%)]"
        aria-hidden
      />
      {/* stamp */}
      <div
        className="absolute right-3 top-3 z-10 flex h-10 w-9 rotate-3 items-center justify-center rounded-[3px] border border-dashed border-white/40 bg-white/5 text-sm text-white/70"
        aria-hidden
      >
        ✦
      </div>
      {/* postmark */}
      <div
        className="absolute right-14 top-3.5 z-10 hidden h-9 w-9 -rotate-6 items-center justify-center rounded-full border border-white/25 text-[6px] uppercase leading-tight tracking-[0.2em] text-white/45 sm:flex"
        aria-hidden
      >
        fm
        <br />
        post
      </div>

      <div className={`relative z-10 flex flex-1 flex-col ${hero ? "p-6 pt-9" : "p-4 pt-6"}`}>
        <p className="text-[9px] uppercase tracking-[0.3em] text-white/45" aria-hidden>
          to · future me
        </p>
        {withTitle ? (
          <p className="mt-0.5 truncate font-hand text-xl leading-relaxed text-white/90">{capsule.title}</p>
        ) : (
          <div className="mt-2 space-y-1.5" aria-hidden>
            <div className="h-1 w-28 rounded-full bg-white/20" />
            <div className="h-1 w-20 rounded-full bg-white/12" />
          </div>
        )}

        <div className={`flex flex-1 items-center ${hero ? "justify-center" : "items-end"}`}>
          <ShapeStatus capsule={capsule} hero={hero} tone="light" />
        </div>

        <div className="flex items-end justify-between gap-2 border-t border-white/10 pt-2">
          <OpensLine capsule={capsule} />
          <span className="wax-seal flex h-9 w-9 shrink-0 items-center justify-center rounded-full" aria-hidden>
            <Lock className="h-3.5 w-3.5 text-fuchsia-100" />
          </span>
        </div>
      </div>
    </div>
  );
}

/* ---- PHOTOS · a polaroid print ------------------------------------ */
function PolaroidShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div
      className={`relative mx-auto w-[94%] -rotate-1 rounded-sm bg-zinc-100 shadow-xl shadow-black/40 ring-1 ring-zinc-300/50 ${
        hero ? "p-3 pb-4" : "p-2.5 pb-3"
      }`}
    >
      <div className="tape absolute -top-2 left-1/2 h-3.5 w-16 -translate-x-1/2 -rotate-3 rounded-sm opacity-80" aria-hidden />
      <div
        className={`relative flex items-center justify-center overflow-hidden rounded-[3px] bg-gradient-to-br from-indigo-950 via-violet-950 to-fuchsia-950 ${
          hero ? "h-44" : "h-24"
        }`}
      >
        <Aperture className={`text-cyan-200/60 ${hero ? "h-9 w-9" : "h-6 w-6"}`} aria-hidden />
        <span
          className="absolute inset-x-0 bottom-1.5 text-center text-[8px] uppercase tracking-[0.25em] text-cyan-100/50"
          aria-hidden
        >
          {capsule.unlockDate ? `develops ${format(new Date(capsule.unlockDate), "MMM d, yyyy")}` : "still developing"}
        </span>
      </div>
      <div className={hero ? "px-2 pb-1 pt-3" : "px-1 pt-2"}>
        {withTitle && (
          <p className="truncate font-hand text-lg leading-snug text-zinc-800">{capsule.title}</p>
        )}
        <div className={`flex items-center ${withTitle ? "mt-1" : "justify-center"} gap-2`}>
          <ShapeStatus capsule={capsule} hero={hero} tone="ink" size="sm" />
        </div>
      </div>
    </div>
  );
}

/* ---- VIDEO · a film strip ------------------------------------------ */
function Sprockets({ wide = false }: { wide?: boolean }) {
  const n = wide ? 12 : 8;
  return (
    <div className="flex justify-between bg-zinc-950 px-2 py-1.5" aria-hidden>
      {[...Array(n)].map((_, i) => (
        <span key={i} className="h-1.5 w-3 rounded-[2px] bg-white/20" />
      ))}
    </div>
  );
}

function FilmShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-zinc-400/30 bg-zinc-950 shadow-lg shadow-black/30">
      <Sprockets wide={hero} />
      <div
        className={`flex flex-col justify-center gap-1 border-y border-white/5 bg-gradient-to-br from-indigo-950/70 via-zinc-950 to-fuchsia-950/60 px-4 ${
          hero ? "min-h-[210px] py-6" : "min-h-[86px] py-3"
        }`}
      >
        {withTitle && (
          <p className={`truncate font-serif font-semibold text-zinc-100 ${hero ? "text-xl" : "text-sm"}`}>
            {capsule.title}
          </p>
        )}
        <div className={hero ? "py-3" : ""}>
          <ShapeStatus capsule={capsule} hero={hero} tone="light" />
        </div>
        <p className="flex items-center gap-2 text-[9px] uppercase tracking-[0.25em] text-zinc-400" aria-hidden>
          <span className="flex h-6 w-6 items-center justify-center rounded-full border border-cyan-200/50 bg-white/5">
            <Play className="ml-px h-2.5 w-2.5 text-cyan-200" />
          </span>
          premieres after unlock
        </p>
      </div>
      <Sprockets wide={hero} />
    </div>
  );
}

/* ---- VOICE · a dictaphone ------------------------------------------ */
const WAVE_BARS = [38, 66, 45, 82, 55, 92, 48, 72, 35, 84, 58, 40, 76, 52, 88, 44, 68, 36, 79, 56];

function VoiceShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-cyan-300/25 bg-cyan-950 shadow-lg shadow-black/30 ${
        hero ? "p-5" : "p-3"
      }`}
    >
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1.5 rounded-full bg-red-500/15 px-2 py-0.5" aria-hidden>
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" aria-hidden />
          <span className="text-[9px] font-semibold uppercase tracking-widest text-red-300">rec</span>
        </span>
        {withTitle && (
          <p className={`min-w-0 flex-1 truncate font-serif font-semibold text-zinc-100 ${hero ? "text-lg" : "text-sm"}`}>
            {capsule.title}
          </p>
        )}
        <Mic className="h-3.5 w-3.5 shrink-0 text-cyan-200/70" aria-hidden />
      </div>
      <div className={`flex items-center gap-[3px] ${hero ? "my-5 h-20" : "my-3 h-10"}`} aria-hidden>
        {WAVE_BARS.map((h, i) => (
          <span
            key={i}
            className="fm-wave flex-1 rounded-full bg-gradient-to-t from-cyan-400/40 to-cyan-200/75"
            style={{ height: `${h}%`, animationDelay: `${(i % 10) * 0.12}s` }}
          />
        ))}
      </div>
      {hero && (
        <div className="mt-4 flex justify-center">
          <ShapeStatus capsule={capsule} hero={hero} tone="light" />
        </div>
      )}
      <div className={`flex items-center justify-between gap-2 border-t border-white/10 ${hero ? "mt-4 pt-3" : "pt-2"}`}>
        {hero ? (
          <span className="text-[9px] uppercase tracking-[0.25em] text-cyan-100/60" aria-hidden>
            voice memo sealed
          </span>
        ) : (
          <OpensLine capsule={capsule} />
        )}
        {hero ? <OpensLine capsule={capsule} /> : <ShapeStatus capsule={capsule} tone="light" />}
      </div>
    </div>
  );
}

/* ---- SONG · a cassette tape ---------------------------------------- */
function Reel({ size, spinning = true }: { size: "sm" | "lg"; spinning?: boolean }) {
  return (
    <span
      className={`relative shrink-0 rounded-full border-2 border-zinc-400/70 ${spinning ? "fm-spin" : "opacity-80"} ${
        size === "lg" ? "h-12 w-12" : "h-7 w-7"
      }`}
      aria-hidden
    >
      <span className={`absolute rounded-full bg-zinc-500 ${size === "lg" ? "inset-[13px]" : "inset-[7px]"}`} />
      <span className={`absolute left-1/2 top-1/2 h-[1.5px] w-2/3 -translate-x-1/2 -translate-y-1/2 bg-zinc-500/60`} />
    </span>
  );
}

function CassetteShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-white/15 bg-gradient-to-b from-zinc-700 to-zinc-900 shadow-lg shadow-black/40 ${
        hero ? "p-4" : "p-2.5"
      }`}
    >
      {/* label strip */}
      <div className="rounded-md border border-white/10 bg-fuchsia-500/15 px-3 py-1.5">
        <div className="flex items-center justify-between gap-2">
          {withTitle ? (
            <p className={`min-w-0 truncate font-hand text-zinc-100 ${hero ? "text-xl" : "text-base"}`}>
              {capsule.title}
            </p>
          ) : (
            <span className="text-[9px] uppercase tracking-[0.25em] text-fuchsia-200/80" aria-hidden>
              mixtape for later
            </span>
          )}
          <span className="shrink-0 text-[8px] uppercase tracking-[0.25em] text-fuchsia-200/70" aria-hidden>
            side A
          </span>
        </div>
        <div className="mt-1 h-1 rounded-full bg-zinc-950/40" aria-hidden />
      </div>
      {/* tape window */}
      <div
        className={`mt-2 flex items-center justify-center gap-6 rounded-md border border-white/10 bg-zinc-950 ${
          hero ? "gap-10 py-5" : "py-2.5"
        }`}
        aria-hidden
      >
        <Reel size={hero ? "lg" : "sm"} />
        <span className={`rounded-sm bg-zinc-800/80 ${hero ? "h-3 w-24" : "h-2 w-14"}`} />
        <Reel size={hero ? "lg" : "sm"} />
      </div>
      {hero && (
        <div className="mt-3 flex justify-center">
          <ShapeStatus capsule={capsule} hero={hero} tone="light" />
        </div>
      )}
      <div className={`flex items-center justify-between gap-2 border-t border-white/10 ${hero ? "mt-3 pt-3" : "mt-2 pt-1.5"}`}>
        <OpensLine capsule={capsule} />
        {hero ? (
          <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-400" aria-hidden>
            plays after unlock
          </span>
        ) : (
          <ShapeStatus capsule={capsule} tone="light" />
        )}
      </div>
    </div>
  );
}

/* ---- GOAL · a mission card ----------------------------------------- */
function GoalShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  const start = new Date(capsule.createdAt).getTime();
  const end = capsule.unlockDate ? new Date(capsule.unlockDate).getTime() : 0;
  const pct = end > start ? Math.min(100, Math.max(3, Math.round(((Date.now() - start) / (end - start)) * 100))) : 3;
  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-emerald-300/25 bg-emerald-950 shadow-lg shadow-black/30 ${
        hero ? "flex min-h-[280px] flex-col p-6" : "p-3"
      }`}
    >
      <div className="flex items-center gap-3">
        <span
          className={`relative flex shrink-0 items-center justify-center rounded-full border-2 border-emerald-300/60 ${
            hero ? "h-16 w-16" : "h-11 w-11"
          }`}
          aria-hidden
        >
          <span className={`absolute rounded-full border-2 border-emerald-300/40 ${hero ? "h-9 w-9" : "h-6 w-6"}`} />
          <Target className={`text-emerald-200 ${hero ? "h-7 w-7" : "h-4 w-4"}`} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[9px] font-semibold uppercase tracking-[0.25em] text-emerald-100/70" aria-hidden>
            mission {pct}% complete
          </p>
          {withTitle && (
            <p className={`truncate font-serif font-semibold text-zinc-100 ${hero ? "mt-1 text-xl" : "text-sm"}`}>
              {capsule.title}
            </p>
          )}
          <div className={`overflow-hidden rounded-full bg-emerald-950/80 ring-1 ring-white/10 ${hero ? "mt-2.5 h-2.5" : "mt-1.5 h-1.5"}`}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-violet-500 to-fuchsia-500 transition-[width] duration-700"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>
      {hero && (
        <div className="mt-auto pt-4">
          <ShapeStatus capsule={capsule} hero={hero} tone="light" />
        </div>
      )}
      <div
        className={`flex items-center justify-between gap-2 border-t border-white/10 ${
          hero ? "mt-4 pt-3" : "mt-2.5 pt-2"
        }`}
      >
        {hero ? (
          <span className="text-[9px] uppercase tracking-[0.25em] text-emerald-100/60" aria-hidden>
            mission in progress
          </span>
        ) : (
          <OpensLine capsule={capsule} />
        )}
        {hero ? <OpensLine capsule={capsule} /> : <ShapeStatus capsule={capsule} tone="light" />}
      </div>
    </div>
  );
}

/* ---- MEMORY · a keepsake box ---------------------------------------- */
function MemoryShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div className={`rounded-xl border border-amber-300/25 bg-amber-950/60 shadow-lg shadow-black/30 ${hero ? "flex min-h-[280px] flex-col p-5" : "p-3"}`}>
      {(withTitle || !hero) && (
        <p className={`truncate font-serif font-semibold text-zinc-100 ${hero ? "mb-3 text-lg" : "mb-2 text-sm"}`}>
          {withTitle ? capsule.title : "memory box"}
        </p>
      )}
      <div className="relative flex-1" aria-hidden>
        <div className={`rounded-t-lg border border-b-0 border-amber-200/30 bg-amber-600/30 ${hero ? "h-7" : "h-4"}`} />
        <div className={`relative rounded-b-lg border border-amber-200/30 bg-amber-900/80 ${hero ? "h-32" : "h-16"}`}>
          <div className="absolute inset-y-0 left-1/2 w-4 -translate-x-1/2 bg-fuchsia-400/20" aria-hidden />
          {hero ? (
            <>
              <span className="wax-seal absolute bottom-2 right-2 flex h-9 w-9 items-center justify-center rounded-full">
                <Heart className="h-3.5 w-3.5 text-fuchsia-100" />
              </span>
              <div className="absolute inset-0 flex items-center justify-center px-4">
                <ShapeStatus capsule={capsule} hero={hero} tone="light" />
              </div>
            </>
          ) : (
            <span className="wax-seal absolute left-1/2 top-1/2 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full">
              <Heart className="h-3 w-3 text-fuchsia-100" />
            </span>
          )}
        </div>
      </div>
      <div className={`flex items-center justify-between gap-2 border-t border-white/10 ${hero ? "mt-4 pt-3" : "mt-2.5 pt-2"}`}>
        <span className="text-[9px] uppercase tracking-[0.25em] text-amber-100/50" aria-hidden>
          {hero ? "do not open until" : "memory box sealed"}
        </span>
        {hero ? <OpensLine capsule={capsule} /> : <ShapeStatus capsule={capsule} tone="light" />}
      </div>
    </div>
  );
}

/* ---- CUSTOM · a wrapped parcel -------------------------------------- */
function ParcelShape({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-amber-200/20 bg-gradient-to-br from-amber-800/90 to-amber-900/90 shadow-lg shadow-black/30 ${
        hero ? "flex min-h-[280px] flex-col p-6" : "p-3"
      }`}
    >
      {/* cross ribbon */}
      <div className="pointer-events-none absolute inset-y-0 left-1/2 w-5 -translate-x-1/2 bg-fuchsia-500/25" aria-hidden />
      <div className="pointer-events-none absolute inset-x-0 top-1/2 h-5 -translate-y-1/2 bg-fuchsia-500/25" aria-hidden />
      {/* fragile stamp */}
      <div
        className="absolute right-3 top-3 z-10 flex h-9 w-9 -rotate-6 items-center justify-center rounded-[3px] border border-dashed border-amber-100/40 text-[6px] font-semibold uppercase leading-tight tracking-widest text-amber-100/60"
        aria-hidden
      >
        fra
        <br />
        gile
      </div>

      <div className={`relative z-10 flex flex-1 flex-col ${hero ? "justify-center" : ""}`}>
        {/* shipping label */}
        <div
          className={`rotate-1 rounded-sm bg-zinc-100 shadow-md ring-1 ring-zinc-400/40 ${hero ? "mx-auto w-[85%] p-4" : "ml-6 mr-2 p-2"}`}
        >
          <p className="text-[7px] font-semibold uppercase tracking-[0.3em] text-zinc-500" aria-hidden>
            special delivery · from past you
          </p>
          {withTitle && (
            <p className={`mt-0.5 truncate font-hand leading-snug text-zinc-800 ${hero ? "text-2xl" : "text-base"}`}>
              {capsule.title}
            </p>
          )}
          <div className={hero ? "mt-3 flex justify-center" : "mt-1"}>
            <ShapeStatus capsule={capsule} hero={hero} tone="ink" size="sm" />
          </div>
        </div>
      </div>

      <div className={`relative z-10 flex items-center justify-between gap-2 border-t border-white/10 ${hero ? "mt-4 pt-3" : "mt-2.5 pt-2"}`}>
        <OpensLine capsule={capsule} />
        <Sparkles className="h-4 w-4 shrink-0 text-fuchsia-200/80" aria-hidden />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* dispatchers                                                          */
/* ------------------------------------------------------------------ */

function ShapeFor({
  capsule,
  hero = false,
  withTitle = true,
}: {
  capsule: CapsuleDTO;
  hero?: boolean;
  withTitle?: boolean;
}) {
  switch (capsule.type) {
    case "letter":
      return <EnvelopeShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "photos":
      return <PolaroidShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "video":
      return <FilmShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "voice":
      return <VoiceShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "song":
      return <CassetteShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "goal":
      return <GoalShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    case "memory":
      return <MemoryShape capsule={capsule} hero={hero} withTitle={withTitle} />;
    default:
      return <ParcelShape capsule={capsule} hero={hero} withTitle={withTitle} />;
  }
}

/** Archive-grid variant: the whole locked card drawn as its own type. */
export function SealedCardVisual({ capsule }: { capsule: CapsuleDTO }) {
  return <ShapeFor capsule={capsule} />;
}

/** Detail-page variant: big scene with the live countdown inside the shape. */
export function SealedHeroVisual({ capsule, withTitle = true }: { capsule: CapsuleDTO; withTitle?: boolean }) {
  return <ShapeFor capsule={capsule} hero withTitle={withTitle} />;
}

/* ------------------------------------------------------------------ */
/* opened visuals — the same forms, caught in their OPENED state       */
/* ------------------------------------------------------------------ */

/** Hand-written “opened on …” line for opened shapes. */
function OpenedLine({ capsule, tone = "light" }: { capsule: CapsuleDTO; tone?: "light" | "ink" }) {
  return (
    <span className={`font-hand text-sm ${tone === "ink" ? "text-zinc-600" : "text-cyan-200/80"}`}>
      opened {capsule.openedAt ? format(new Date(capsule.openedAt), "MMM d, yyyy") : "✓"}
    </span>
  );
}

/* ---- LETTER · opened envelope, letter pulled out ------------------ */
function OpenedEnvelope({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="relative flex min-h-[172px] flex-col overflow-hidden rounded-2xl border border-indigo-300/30 bg-gradient-to-br from-indigo-950 via-violet-950 to-fuchsia-950 shadow-lg shadow-black/30">
      {/* opened flap — a triangle rising from the top edge */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[54%] bg-gradient-to-b from-white/[0.16] to-transparent [clip-path:polygon(0_0,50%_100%,100%_0)]"
        aria-hidden
      />
      {/* the letter, pulled out */}
      <div className="relative z-10 mx-auto mt-3 w-[86%] -rotate-1 rounded-[3px] bg-zinc-100 px-3 py-2 shadow-lg shadow-black/40 ring-1 ring-zinc-300/60">
        <p className="text-[8px] font-semibold uppercase tracking-[0.3em] text-zinc-500" aria-hidden>
          from · past me
        </p>
        <p className="mt-0.5 line-clamp-2 font-hand text-[15px] leading-snug text-zinc-800">
          {capsule.content?.slice(0, 110) || "a letter from the person you used to be"}
        </p>
      </div>
      {/* envelope front */}
      <div className="relative z-20 mt-auto flex items-center justify-between gap-2 border-t border-white/10 bg-gradient-to-t from-black/30 to-transparent px-4 pb-3 pt-2.5">
        <OpenedLine capsule={capsule} />
        <span className="wax-seal flex h-9 w-9 shrink-0 items-center justify-center rounded-full opacity-80" aria-hidden>
          <Unlock className="h-3.5 w-3.5 text-fuchsia-100" />
        </span>
      </div>
    </div>
  );
}

/* ---- PHOTOS · developed polaroid ----------------------------------- */
function OpenedPolaroid({ capsule }: { capsule: CapsuleDTO }) {
  const photo = capsule.media?.find((m) => m.kind === "photo");
  return (
    <div className="relative mx-auto w-[94%] rotate-1 rounded-sm bg-zinc-100 p-2.5 pb-3 shadow-xl shadow-black/40 ring-1 ring-zinc-300/50">
      <div className="tape absolute -top-2 left-1/2 h-3.5 w-16 -translate-x-1/2 rotate-2 rounded-sm opacity-80" aria-hidden />
      <div className="relative flex h-24 items-center justify-center overflow-hidden rounded-[3px] bg-gradient-to-b from-amber-200 via-rose-300 to-violet-500">
        {photo ? (
          <img src={photo.url} alt="" loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <Sun className="h-6 w-6 text-amber-100/90" aria-hidden />
        )}
        <span
          className="absolute inset-x-0 bottom-1.5 text-center text-[8px] uppercase tracking-[0.25em] text-white/85 [text-shadow:0_1px_2px_rgba(0,0,0,0.6)]"
          aria-hidden
        >
          developed
        </span>
      </div>
      <div className="px-1 pt-2">
        <p className="truncate font-hand text-lg leading-snug text-zinc-800">{capsule.title}</p>
        <div className="mt-0.5 flex items-center justify-between">
          <OpenedLine capsule={capsule} tone="ink" />
        </div>
      </div>
    </div>
  );
}

/* ---- VIDEO · watched film strip ------------------------------------- */
function OpenedFilm({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-zinc-400/30 bg-zinc-950 shadow-lg shadow-black/30">
      <Sprockets />
      <div className="flex min-h-[86px] flex-col justify-center gap-1.5 border-y border-white/5 bg-gradient-to-br from-indigo-950/60 via-zinc-950 to-fuchsia-950/50 px-4 py-3">
        <p className="truncate font-serif text-sm font-semibold text-zinc-100">{capsule.title}</p>
        <div className="flex items-center justify-between gap-2">
          <p className="flex items-center gap-2 text-[9px] uppercase tracking-[0.25em] text-zinc-400" aria-hidden>
            <span className="flex h-6 w-6 items-center justify-center rounded-full border border-cyan-200/50 bg-white/10">
              <Play className="ml-px h-2.5 w-2.5 text-cyan-200" />
            </span>
            watched · replay
          </p>
          <OpenedLine capsule={capsule} />
        </div>
      </div>
      <Sprockets />
    </div>
  );
}

/* ---- VOICE · dictaphone, heard --------------------------------------- */
function OpenedVoice({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-cyan-300/25 bg-cyan-950 p-3 shadow-lg shadow-black/30">
      <div className="flex items-center gap-2">
        <span
          className="rounded-full bg-cyan-400/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-widest text-cyan-300"
          aria-hidden
        >
          played
        </span>
        <p className="min-w-0 flex-1 truncate font-serif text-sm font-semibold text-zinc-100">{capsule.title}</p>
        <Mic className="h-3.5 w-3.5 shrink-0 text-cyan-200/70" aria-hidden />
      </div>
      <div className="my-3 flex h-10 items-center gap-[3px]" aria-hidden>
        {WAVE_BARS.map((h, i) => (
          <span key={i} className="flex-1 rounded-full bg-cyan-300/40" style={{ height: `${h}%` }} />
        ))}
      </div>
      <div className="flex items-center justify-between gap-2 border-t border-white/10 pt-2">
        <span className="text-[9px] uppercase tracking-[0.25em] text-cyan-100/60" aria-hidden>
          voice memo · heard
        </span>
        <OpenedLine capsule={capsule} />
      </div>
    </div>
  );
}

/* ---- SONG · cassette, played ------------------------------------------ */
function OpenedCassette({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-white/15 bg-gradient-to-b from-zinc-700 to-zinc-900 p-2.5 shadow-lg shadow-black/40">
      <div className="rounded-md border border-white/10 bg-fuchsia-500/15 px-3 py-1.5">
        <div className="flex items-center justify-between gap-2">
          <p className="min-w-0 truncate font-hand text-base text-zinc-100">{capsule.title}</p>
          <span className="shrink-0 text-[8px] uppercase tracking-[0.25em] text-fuchsia-200/70" aria-hidden>
            side A
          </span>
        </div>
        <div className="mt-1 h-1 rounded-full bg-zinc-950/40" aria-hidden />
      </div>
      <div
        className="mt-2 flex items-center justify-center gap-6 rounded-md border border-white/10 bg-zinc-950 py-2.5"
        aria-hidden
      >
        <Reel size="sm" spinning={false} />
        <span className="h-2 w-14 rounded-sm bg-zinc-800/80" />
        <Reel size="sm" spinning={false} />
      </div>
      <div className="mt-2 flex items-center justify-between gap-2 border-t border-white/10 pt-1.5">
        <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-400" aria-hidden>
          listened · side A
        </span>
        <OpenedLine capsule={capsule} />
      </div>
    </div>
  );
}

/* ---- GOAL · mission, closed -------------------------------------------- */
const OUTCOME_META: Record<string, { emoji: string; label: string }> = {
  yes: { emoji: "✅", label: "mission complete" },
  almost: { emoji: "🟡", label: "almost there" },
  not_yet: { emoji: "❌", label: "not this time" },
};

function OpenedGoal({ capsule }: { capsule: CapsuleDTO }) {
  const outcome = capsule.goalOutcome ? OUTCOME_META[capsule.goalOutcome] : null;
  return (
    <div className="rounded-xl border border-emerald-300/25 bg-emerald-950 p-3 shadow-lg shadow-black/30">
      <div className="flex items-center gap-3">
        <span
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-emerald-300/60 text-lg"
          aria-hidden
        >
          {outcome ? outcome.emoji : <Target className="h-4 w-4 text-emerald-200" />}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[9px] font-semibold uppercase tracking-[0.25em] text-emerald-100/70" aria-hidden>
            {outcome ? outcome.label : "mission closed"}
          </p>
          <p className="truncate font-serif text-sm font-semibold text-zinc-100">{capsule.title}</p>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-emerald-950/80 ring-1 ring-white/10">
            <div className="h-full w-full rounded-full bg-gradient-to-r from-cyan-400 via-violet-500 to-fuchsia-500" />
          </div>
        </div>
      </div>
      {capsule.reflection && (
        <p className="mt-2 line-clamp-1 font-hand text-sm text-emerald-100/70">“{capsule.reflection}”</p>
      )}
      <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-white/10 pt-2">
        <span className="text-[9px] uppercase tracking-[0.25em] text-emerald-100/60" aria-hidden>
          the wait is over
        </span>
        <OpenedLine capsule={capsule} />
      </div>
    </div>
  );
}

/* ---- MEMORY · box, opened ---------------------------------------------- */
function OpenedMemory({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="rounded-xl border border-amber-300/25 bg-amber-950/60 p-3 shadow-lg shadow-black/30">
      <p className="mb-2 truncate font-serif text-sm font-semibold text-zinc-100">{capsule.title}</p>
      <div className="relative" aria-hidden>
        {/* lid, set aside */}
        <div className="relative z-10 -mb-1 -ml-1 h-4 w-[70%] -rotate-3 rounded-t-lg border border-b-0 border-amber-200/40 bg-amber-600/40" />
        {/* glowing interior */}
        <div className="relative h-16 overflow-hidden rounded-b-lg rounded-tr-lg border border-amber-200/30 bg-amber-900/80">
          <div className="absolute inset-0 bg-gradient-to-t from-amber-500/25 via-transparent to-transparent" />
          <Heart className="absolute left-1/2 top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 text-amber-200" />
          <Sparkles className="absolute right-2.5 top-2 h-3 w-3 text-amber-100/70" />
        </div>
      </div>
      <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-white/10 pt-2">
        <span className="text-[9px] uppercase tracking-[0.25em] text-amber-100/50" aria-hidden>
          memory box opened
        </span>
        <OpenedLine capsule={capsule} />
      </div>
    </div>
  );
}

/* ---- CUSTOM · parcel, unwrapped ----------------------------------------- */
function OpenedParcel({ capsule }: { capsule: CapsuleDTO }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-amber-200/20 bg-gradient-to-br from-amber-800/90 to-amber-900/90 p-3 shadow-lg shadow-black/30">
      {/* opened cardboard flaps */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-7 bg-gradient-to-b from-amber-500/30 to-transparent [clip-path:polygon(0_0,50%_100%,100%_0)]"
        aria-hidden
      />
      {/* ribbon, untied */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-10 w-5 -translate-x-1/2 bg-fuchsia-500/20" aria-hidden />
      <div className="relative z-10 pt-2">
        <div className="ml-6 mr-2 rotate-1 rounded-sm bg-zinc-100 p-2 shadow-md ring-1 ring-zinc-400/40">
          <p className="text-[7px] font-semibold uppercase tracking-[0.3em] text-zinc-500" aria-hidden>
            unwrapped · from past you
          </p>
          <p className="truncate font-hand text-base leading-snug text-zinc-800">{capsule.title}</p>
          {capsule.content && (
            <p className="line-clamp-1 font-hand text-sm text-zinc-600">{capsule.content.slice(0, 70)}</p>
          )}
        </div>
      </div>
      <div className="relative z-10 mt-2.5 flex items-center justify-between gap-2 border-t border-white/10 pt-2">
        <OpenedLine capsule={capsule} />
        <Sparkles className="h-4 w-4 shrink-0 text-fuchsia-200/80" aria-hidden />
      </div>
    </div>
  );
}

/** Archive-grid variant for OPENED capsules: the type's form, opened. */
export function OpenedCardVisual({ capsule }: { capsule: CapsuleDTO }) {
  switch (capsule.type) {
    case "letter":
      return <OpenedEnvelope capsule={capsule} />;
    case "photos":
      return <OpenedPolaroid capsule={capsule} />;
    case "video":
      return <OpenedFilm capsule={capsule} />;
    case "voice":
      return <OpenedVoice capsule={capsule} />;
    case "song":
      return <OpenedCassette capsule={capsule} />;
    case "goal":
      return <OpenedGoal capsule={capsule} />;
    case "memory":
      return <OpenedMemory capsule={capsule} />;
    default:
      return <OpenedParcel capsule={capsule} />;
  }
}

/* ------------------------------------------------------------------ */
/* small emblems — miniaturized glyphs for tiles & timeline             */
/* ------------------------------------------------------------------ */

export function SealedEmblem({ type, className = "h-11 w-11" }: { type: CapsuleType; className?: string }) {
  const base = `relative block shrink-0 overflow-hidden rounded-lg border ${className}`;
  switch (type) {
    case "letter":
      return (
        <span className={`${base} border-indigo-300/40 bg-gradient-to-br from-indigo-500/45 to-fuchsia-500/35`} aria-hidden>
          <span className="absolute inset-x-0 top-0 h-3/5 bg-white/15 [clip-path:polygon(0_0,100%_0,50%_100%)]" />
          <span className="absolute bottom-1 left-1/2 h-1 w-6 -translate-x-1/2 rounded-full bg-white/25" />
        </span>
      );
    case "photos":
      return (
        <span className={`${base} border-white/20 bg-zinc-100 p-[3px] pb-[7px] shadow`} aria-hidden>
          <span className="block h-full w-full rounded-[2px] bg-gradient-to-br from-indigo-950 to-fuchsia-950" />
        </span>
      );
    case "video":
      return (
        <span className={`${base} border-zinc-400/40 bg-zinc-900`} aria-hidden>
          <span className="absolute inset-x-1 top-1 flex justify-between" aria-hidden>
            {[...Array(4)].map((_, i) => (
              <span key={i} className="h-1 w-1.5 rounded-[1px] bg-white/25" />
            ))}
          </span>
          <Play className="absolute left-1/2 top-[58%] h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 text-cyan-200" />
        </span>
      );
    case "voice":
      return (
        <span className={`${base} flex items-center justify-center gap-[2px] border-cyan-300/40 bg-cyan-950/60 px-1.5`} aria-hidden>
          {[45, 80, 55, 90, 40].map((h, i) => (
            <span key={i} className="w-[3px] rounded-full bg-cyan-300/80" style={{ height: `${h}%` }} />
          ))}
        </span>
      );
    case "song":
      return (
        <span className={`${base} border-fuchsia-300/40 bg-zinc-800`} aria-hidden>
          <span className="absolute inset-x-1.5 top-1.5 h-2 rounded-[2px] bg-fuchsia-400/40" />
          <span className="absolute bottom-1.5 left-2 h-2.5 w-2.5 rounded-full border-2 border-zinc-400" />
          <span className="absolute bottom-1.5 right-2 h-2.5 w-2.5 rounded-full border-2 border-zinc-400" />
        </span>
      );
    case "goal":
      return (
        <span className={`${base} flex items-center justify-center border-emerald-300/40 bg-emerald-950/60`} aria-hidden>
          <Target className="h-5 w-5 text-emerald-200" />
        </span>
      );
    case "memory":
      return (
        <span className={`${base} border-amber-300/40 bg-amber-900/50`} aria-hidden>
          <span className="absolute inset-x-0 top-1.5 h-1.5 bg-amber-200/30" aria-hidden />
          <Heart className="absolute left-1/2 top-[62%] h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 text-amber-200" />
        </span>
      );
    default:
      return (
        <span className={`${base} border-violet-300/40 bg-violet-950/60`} aria-hidden>
          <span className="absolute inset-y-0 left-1/2 w-1.5 -translate-x-1/2 bg-fuchsia-300/30" />
          <span className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 bg-fuchsia-300/30" />
          <Sparkles className="absolute left-1/2 top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 text-fuchsia-100" />
        </span>
      );
  }
}
