import type { CapsuleDTO } from "@/lib/capsules";

export interface CreateCapsulePayload {
  type: string;
  title: string;
  content?: string;
  message?: string;
  mood?: string;
  location?: string;
  tags?: string;
  theme?: string;
  lockType: string;
  lockLabel?: string;
  lockDate?: string; // yyyy-mm-dd
  lockTime?: string; // HH:mm
  unlockDays?: number;
  birthday?: string; // yyyy-mm-dd (month/day used)
  isSurprise?: boolean;
  recurring?: string;
  media?: { kind: string; url: string; caption?: string }[];
}

async function handle<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || "Something went wrong");
  }
  return data as T;
}

export async function fetchCapsules(): Promise<CapsuleDTO[]> {
  const res = await fetch("/api/capsules", { cache: "no-store" });
  const data = await handle<{ capsules: CapsuleDTO[] }>(res);
  return data.capsules;
}

export async function createCapsule(payload: CreateCapsulePayload): Promise<CapsuleDTO> {
  const res = await fetch("/api/capsules", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await handle<{ capsule: CapsuleDTO }>(res);
  return data.capsule;
}

export async function openCapsule(id: string): Promise<CapsuleDTO> {
  const res = await fetch(`/api/capsules/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "open" }),
  });
  const data = await handle<{ capsule: CapsuleDTO }>(res);
  return data.capsule;
}

export async function setGoalOutcome(
  id: string,
  goalOutcome: string,
  reflection?: string
): Promise<CapsuleDTO> {
  const res = await fetch(`/api/capsules/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "goal_outcome", goalOutcome, reflection }),
  });
  const data = await handle<{ capsule: CapsuleDTO }>(res);
  return data.capsule;
}

export async function setReflection(id: string, reflection: string): Promise<CapsuleDTO> {
  const res = await fetch(`/api/capsules/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "reflection", reflection }),
  });
  const data = await handle<{ capsule: CapsuleDTO }>(res);
  return data.capsule;
}

export async function deleteCapsule(id: string): Promise<void> {
  const res = await fetch(`/api/capsules/${id}`, { method: "DELETE" });
  await handle<{ ok: boolean }>(res);
}
