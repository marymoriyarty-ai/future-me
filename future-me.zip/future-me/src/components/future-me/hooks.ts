"use client";

import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchCapsules,
  createCapsule,
  openCapsule,
  setGoalOutcome,
  setReflection,
  deleteCapsule,
  type CreateCapsulePayload,
} from "./api";
import type { CapsuleDTO } from "@/lib/capsules";

/** Ticking clock shared by all countdowns (updates every second). */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState<number>(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function useCapsules() {
  return useQuery<CapsuleDTO[], Error>({
    queryKey: ["capsules"],
    queryFn: fetchCapsules,
    staleTime: 10_000,
  });
}

export function useCapsuleMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["capsules"] });

  const create = useMutation({
    mutationFn: (payload: CreateCapsulePayload) => createCapsule(payload),
    onSuccess: invalidate,
  });

  const open = useMutation({
    mutationFn: (id: string) => openCapsule(id),
    onSuccess: invalidate,
  });

  const goal = useMutation({
    mutationFn: ({ id, outcome, reflection }: { id: string; outcome: string; reflection?: string }) =>
      setGoalOutcome(id, outcome, reflection),
    onSuccess: invalidate,
  });

  const reflect = useMutation({
    mutationFn: ({ id, reflection }: { id: string; reflection: string }) =>
      setReflection(id, reflection),
    onSuccess: invalidate,
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteCapsule(id),
    onSuccess: invalidate,
  });

  return { create, open, goal, reflect, remove };
}
