"use client";

import { useEffect, useMemo, useRef } from "react";

type Star = {
  left: number;
  top: number;
  size: number;
  color: string;
  dur: number;
  delay: number;
  peak: number;
  glow: boolean;
  glint: boolean;
};

type ShootingStar = {
  left: number;
  top: number;
  ang: number;
  dist: number;
  cycle: number;
  delay: number;
};

const STAR_COLORS = {
  white: "oklch(0.96 0.015 250 / 0.95)",
  cyan: "oklch(0.85 0.09 220 / 0.95)",
  gold: "oklch(0.85 0.1 85 / 0.95)",
  fuchsia: "oklch(0.82 0.1 340 / 0.95)",
} as const;

/** Deterministic PRNG so the server and client render the exact same sky. */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeStars(
  count: number,
  seed: number,
  sizeMin: number,
  sizeMax: number,
  peakMin: number,
  peakMax: number,
  opts?: { glintMin?: number; band?: boolean }
): Star[] {
  const rnd = mulberry32(seed);
  const hues = ["white", "white", "white", "cyan", "gold", "fuchsia"] as const;
  return Array.from({ length: count }, () => {
    const size = sizeMin + rnd() * (sizeMax - sizeMin);
    const left = rnd() * 100;
    // stars in the "milky-way" band hug a diagonal line across the sky
    const top = opts?.band
      ? 14 + left * 0.34 + (rnd() - 0.5) * 13
      : rnd() * 100;
    const useWhite = opts?.band && rnd() < 0.75;
    return {
      left,
      top: ((top % 100) + 100) % 100,
      size,
      color: useWhite ? STAR_COLORS.white : STAR_COLORS[hues[Math.floor(rnd() * hues.length)]],
      dur: 2.5 + rnd() * 4.5,
      delay: -rnd() * 9,
      peak: peakMin + rnd() * (peakMax - peakMin),
      glow: size > 2.3,
      glint: opts?.glintMin !== undefined && size >= opts.glintMin,
    };
  });
}

/**
 * Living deep-space background: five parallax layers of twinkling stars
 * in clearly different sizes (deep dust, a diagonal milky-way band, mid
 * stars, large stars and a few big glinting heroes) that shift gently
 * with the pointer, drifting nebula clouds, shooting stars crossing every
 * few seconds, and a soft moonlight halo following the cursor. Purely
 * decorative — fixed, pointer-events-none, honors reduced motion (static
 * sky, no meteors, no parallax).
 */
export function InteractiveBackground() {
  const ibRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);

  const layers = useMemo(
    () => [
      { depth: 6, stars: makeStars(80, 101, 0.6, 1.4, 0.3, 0.6) },
      { depth: 12, stars: makeStars(60, 404, 0.7, 1.5, 0.28, 0.55, { band: true }) },
      { depth: 18, stars: makeStars(34, 202, 1.3, 2.6, 0.5, 0.85) },
      { depth: 28, stars: makeStars(13, 303, 2.6, 4.2, 0.7, 1, { glintMin: 3.4 }) },
      { depth: 40, stars: makeStars(5, 505, 4.5, 6, 0.9, 1, { glintMin: 4.5 }) },
    ],
    []
  );

  const meteors = useMemo<ShootingStar[]>(() => {
    const rnd = mulberry32(777);
    return [
      { left: 8 + rnd() * 40, top: 4 + rnd() * 25, ang: 32 + rnd() * 14, dist: 320 + rnd() * 180, cycle: 11 + rnd() * 6, delay: rnd() * 6 },
      { left: 30 + rnd() * 50, top: 2 + rnd() * 20, ang: 138 + rnd() * 14, dist: 300 + rnd() * 160, cycle: 15 + rnd() * 7, delay: 5 + rnd() * 6 },
      { left: 5 + rnd() * 30, top: 8 + rnd() * 30, ang: 25 + rnd() * 12, dist: 260 + rnd() * 140, cycle: 19 + rnd() * 8, delay: 10 + rnd() * 8 },
    ];
  }, []);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    // parallax: normalized pointer position (-0.5 .. 0.5)
    const target = { x: 0, y: 0 };
    const pos = { x: 0, y: 0 };
    // moonlight halo: follows the raw pointer, lazily
    const glow = {
      x: window.innerWidth / 2,
      y: window.innerHeight * 0.32,
      tx: window.innerWidth / 2,
      ty: window.innerHeight * 0.32,
    };
    const onMove = (e: PointerEvent) => {
      target.x = e.clientX / window.innerWidth - 0.5;
      target.y = e.clientY / window.innerHeight - 0.5;
      glow.tx = e.clientX;
      glow.ty = e.clientY;
    };
    const tick = () => {
      pos.x += (target.x - pos.x) * 0.06;
      pos.y += (target.y - pos.y) * 0.06;
      ibRef.current?.style.setProperty("--px", pos.x.toFixed(4));
      ibRef.current?.style.setProperty("--py", pos.y.toFixed(4));
      glow.x += (glow.tx - glow.x) * 0.055;
      glow.y += (glow.ty - glow.y) * 0.055;
      glowRef.current?.style.setProperty("--gx", `${glow.x.toFixed(1)}px`);
      glowRef.current?.style.setProperty("--gy", `${glow.y.toFixed(1)}px`);
      raf = requestAnimationFrame(tick);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div ref={ibRef} className="fm-ib" aria-hidden>
      <div ref={glowRef} className="fm-cursor-glow" />

      {/* nebula clouds */}
      <span className="fm-nebula fm-nebula-violet" />
      <span className="fm-nebula fm-nebula-magenta" />
      <span className="fm-nebula fm-nebula-cyan" />

      {/* faint milky-way band crossing the sky */}
      <span className="fm-milkyway" />

      {/* twinkling stars in three parallax depth layers */}
      {layers.map((layer, li) => (
        <div
          key={li}
          className="fm-stars-layer"
          style={{ "--depth": layer.depth } as React.CSSProperties}
        >
          {layer.stars.map((s, i) => (
            <span
              key={i}
              className={`fm-star${s.glint ? " fm-star-glint" : ""}`}
              style={
                {
                  left: `${s.left}%`,
                  top: `${s.top}%`,
                  width: s.size,
                  height: s.size,
                  background: s.color,
                  boxShadow: s.glow ? `0 0 ${s.size * 3}px ${s.color}` : undefined,
                  "--dur": `${s.dur.toFixed(2)}s`,
                  "--delay": `${s.delay.toFixed(2)}s`,
                  "--peak": s.peak.toFixed(2),
                } as React.CSSProperties
              }
            />
          ))}
        </div>
      ))}

      {/* shooting stars */}
      {meteors.map((m, i) => (
        <span
          key={i}
          className="fm-shooting-star"
          style={
            {
              left: `${m.left}%`,
              top: `${m.top}%`,
              "--ang": `${m.ang.toFixed(0)}deg`,
              "--dist": `${m.dist.toFixed(0)}px`,
              "--cycle": `${m.cycle.toFixed(1)}s`,
              "--delay": `${m.delay.toFixed(1)}s`,
            } as React.CSSProperties
          }
        />
      ))}
    </div>
  );
}
