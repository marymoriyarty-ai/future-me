"use client";

import { timeRemaining, type Remaining } from "@/lib/capsules";
import { useNow } from "./hooks";

type Tone = "default" | "light" | "ink";

const TONE_VALUE: Record<Tone, string> = {
  default: "",
  light: "text-white",
  ink: "text-zinc-900",
};
const TONE_LABEL: Record<Tone, string> = {
  default: "",
  light: "text-white/55",
  ink: "text-zinc-500",
};
const TONE_COLON: Record<Tone, string> = {
  default: "text-muted-foreground/50",
  light: "text-white/40",
  ink: "text-zinc-400",
};

function Unit({
  value,
  label,
  size = "lg",
  tone = "default",
}: {
  value: number;
  label: string;
  size?: "lg" | "sm";
  tone?: Tone;
}) {
  const big = size === "lg";
  return (
    <div className="flex flex-col items-center">
      <div
        className={`${
          big
            ? "font-serif text-4xl sm:text-5xl font-semibold tabular-nums leading-none"
            : "font-serif text-3xl font-semibold tabular-nums leading-none"
        } ${TONE_VALUE[tone]}`}
      >
        {String(value).padStart(2, "0")}
      </div>
      <div className={`text-[10px] uppercase tracking-[0.2em] text-muted-foreground ${big ? "mt-1.5" : "mt-1"} ${TONE_LABEL[tone]}`}>
        {label}
      </div>
    </div>
  );
}

/** Big hero countdown (days / hours / minutes / seconds). */
export function CountdownHero({
  target,
  tone = "default",
  size = "lg",
}: {
  target: string | Date;
  tone?: Tone;
  size?: "lg" | "sm";
}) {
  useNow();
  const r = timeRemaining(target);
  if (r.total <= 0) {
    return (
      <div className={`font-hand text-3xl ${tone === "light" ? "text-white" : tone === "ink" ? "text-zinc-800" : "text-primary"}`}>
        it&apos;s time…
      </div>
    );
  }
  const colon = size === "lg" ? "text-4xl" : "text-3xl";
  return (
    <div className={`flex items-start justify-center ${size === "lg" ? "gap-5 sm:gap-8" : "gap-3.5 sm:gap-5"}`}>
      <Unit value={r.days} label="days" size={size} tone={tone} />
      <span className={`mt-0.5 font-serif ${colon} ${TONE_COLON[tone]}`}>:</span>
      <Unit value={r.hours} label="hours" size={size} tone={tone} />
      <span className={`mt-0.5 font-serif ${colon} ${TONE_COLON[tone]}`}>:</span>
      <Unit value={r.minutes} label="minutes" size={size} tone={tone} />
      <span className={`mt-0.5 hidden font-serif sm:inline ${colon} ${TONE_COLON[tone]}`}>:</span>
      <div className="hidden sm:block">
        <Unit value={r.seconds} label="seconds" size={size} tone={tone} />
      </div>
    </div>
  );
}

/** Compact countdown used on cards. */
export function CountdownChip({ target, remaining }: { target?: string | Date; remaining?: Remaining }) {
  useNow(15000);
  const r = remaining ?? (target ? timeRemaining(target) : null);
  if (!r || r.total <= 0) return null;
  return (
    <span className="tabular-nums">
      {r.days > 0 && (
        <>
          {r.days} <span className="text-[0.8em] opacity-70">d</span>
        </>
      )}
      {r.days <= 0 && (
        <>
          {r.hours} <span className="text-[0.8em] opacity-70">h</span> {r.minutes}{" "}
          <span className="text-[0.8em] opacity-70">m</span>
        </>
      )}
      {r.days > 0 && r.hours > 0 && r.days <= 30 && (
        <>
          {" "}
          {r.hours} <span className="text-[0.8em] opacity-70">h</span>
        </>
      )}
    </span>
  );
}
