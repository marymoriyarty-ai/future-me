"use client";

import { useEffect, useRef } from "react";

/** Fires onDone exactly once, `delay` ms after mount — immune to re-renders. */
function useOnceTimer(onDone: () => void, delay: number) {
  const doneRef = useRef(onDone);
  useEffect(() => {
    doneRef.current = onDone;
  }, [onDone]);
  useEffect(() => {
    const t = window.setTimeout(() => doneRef.current(), delay);
    return () => window.clearTimeout(t);
  }, []);
}

const SPARKS = Array.from({ length: 6 }, (_, i) => {
  const angle = (i / 6) * Math.PI * 2;
  return {
    sx: `${Math.round(Math.cos(angle) * 70)}px`,
    sy: `${Math.round(Math.sin(angle) * 70)}px`,
    i,
  };
});

/**
 * Envelope sealing animation: flap folds down, wax seal stamps in,
 * sparkles, then onDone() fires. Pure CSS — deterministic and safe
 * to render inside other animation trees.
 */
export function SealEnvelopeOverlay({ onDone }: { onDone: () => void }) {
  useOnceTimer(onDone, 2700);

  return (
    <div className="fm-overlay fixed inset-0 z-[80] flex items-center justify-center bg-background/85 backdrop-blur-sm" role="status" aria-label="Sealing your capsule">
      <div style={{ perspective: "800px" }}>
        <div className="fm-envelope relative h-40 w-60 sm:h-48 sm:w-72">
          {/* back */}
          <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-indigo-300 to-violet-300 shadow-xl dark:from-indigo-950 dark:to-violet-900" />
          {/* letter settling inside */}
          <div className="fm-letter-down absolute inset-x-5 top-3 bottom-6 rounded-md bg-white shadow-inner dark:bg-indigo-100">
            <div className="mx-auto mt-3 h-1.5 w-24 rounded bg-muted" />
            <div className="mx-auto mt-2 h-1.5 w-32 rounded bg-muted" />
          </div>
          {/* front pockets */}
          <div className="absolute inset-0 rounded-xl bg-gradient-to-tr from-violet-400 to-indigo-400 shadow-md dark:from-violet-900 dark:to-indigo-900" />
          <div className="absolute inset-0 rounded-xl bg-gradient-to-bl from-violet-300 to-cyan-200 [clip-path:polygon(0_45%,50%_78%,100%_45%,100%_100%,0_100%)] dark:from-violet-950 dark:to-indigo-950" />
          {/* flap closing */}
          <div className="fm-flap-close absolute inset-x-0 top-0 h-[55%] rounded-t-xl bg-gradient-to-b from-indigo-400 to-violet-400 [clip-path:polygon(0_0,100%_0,50%_100%)] dark:from-indigo-900 dark:to-violet-900" />
          {/* wax seal */}
          <div className="wax-seal fm-seal-stamp absolute left-1/2 top-[52%] flex h-14 w-14 items-center justify-center rounded-full">
            <span className="font-serif text-xl font-bold text-fuchsia-100/90">FM</span>
          </div>
          {/* sparkles */}
          {SPARKS.map((s) => (
            <div
              key={s.i}
              className="fm-spark absolute left-1/2 top-[52%] h-1.5 w-1.5 rounded-full bg-cyan-200"
              style={{ "--sx": s.sx, "--sy": s.sy, "--i": s.i } as React.CSSProperties}
            />
          ))}
        </div>
        <p className="fm-hint mt-6 text-center font-hand text-2xl text-primary">
          Sealed until the day comes…
        </p>
      </div>
    </div>
  );
}

/**
 * Envelope opening animation: wax cracks away, flap lifts, letter rises.
 * Then onDone() fires so the caller can reveal the content. Pure CSS.
 */
export function OpenEnvelopeOverlay({ onDone }: { onDone: () => void }) {
  useOnceTimer(onDone, 2500);

  return (
    <div className="fm-overlay fixed inset-0 z-[80] flex items-center justify-center bg-background/85 backdrop-blur-sm" role="status" aria-label="Opening your capsule">
      <div style={{ perspective: "800px" }}>
        <div className="fm-envelope relative h-40 w-60 sm:h-48 sm:w-72">
          {/* glow behind */}
          <div className="fm-glow absolute -inset-6 rounded-3xl bg-cyan-400/30 blur-2xl" />
          {/* letter rising out */}
          <div className="fm-letter-rise absolute inset-x-6 bottom-6 z-0 rounded-md bg-white p-3 shadow-lg dark:bg-indigo-100">
            <div className="mx-auto h-1.5 w-28 rounded bg-muted" />
            <div className="mx-auto mt-2 h-1.5 w-36 rounded bg-muted" />
            <div className="mx-auto mt-2 h-1.5 w-24 rounded bg-muted" />
            <div className="mx-auto mt-5 text-center font-hand text-xl text-primary">for you ♥</div>
          </div>
          {/* envelope back */}
          <div className="absolute inset-0 z-10 rounded-xl bg-gradient-to-br from-indigo-300 to-violet-300 shadow-xl dark:from-indigo-950 dark:to-violet-900" />
          {/* front pockets */}
          <div className="absolute inset-0 z-20 rounded-xl bg-gradient-to-tr from-violet-400 to-indigo-400 shadow-md dark:from-violet-900 dark:to-indigo-900" />
          <div className="absolute inset-0 z-20 rounded-xl bg-gradient-to-bl from-violet-300 to-cyan-200 [clip-path:polygon(0_45%,50%_78%,100%_45%,100%_100%,0_100%)] dark:from-violet-950 dark:to-indigo-950" />
          {/* flap opening */}
          <div className="fm-flap-open absolute inset-x-0 top-0 z-30 h-[55%] rounded-t-xl bg-gradient-to-b from-indigo-400 to-violet-400 [clip-path:polygon(0_0,100%_0,50%_100%)] dark:from-indigo-900 dark:to-violet-900" />
          {/* wax seal cracking */}
          <div className="wax-seal fm-seal-crack absolute left-1/2 top-[52%] z-40 flex h-14 w-14 items-center justify-center rounded-full">
            <span className="font-serif text-xl font-bold text-fuchsia-100/90">FM</span>
          </div>
        </div>
        <p className="fm-hint mt-6 text-center font-hand text-2xl text-primary">
          from your past self…
        </p>
      </div>
    </div>
  );
}

/**
 * Renders the requested overlay. No AnimatePresence — mounting and
 * unmounting are instant, animations are pure CSS.
 */
export function EnvelopeOverlay({
  mode,
  onDone,
}: {
  mode: "seal" | "open" | null;
  onDone: () => void;
}) {
  if (!mode) return null;
  return mode === "seal" ? (
    <SealEnvelopeOverlay onDone={onDone} />
  ) : (
    <OpenEnvelopeOverlay onDone={onDone} />
  );
}
