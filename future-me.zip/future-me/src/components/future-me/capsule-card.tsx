"use client";

import { TYPE_META, isReadyToOpen, type CapsuleDTO, type CapsuleType } from "@/lib/capsules";
import { motion } from "framer-motion";
import { OpenedCardVisual, SealedCardVisual } from "./sealed-visual";
import { useNow } from "./hooks";

export function TypeBadge({ type, className }: { type: CapsuleType; className?: string }) {
  const meta = TYPE_META[type];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${className || ""}`}
    >
      <span aria-hidden>{meta.emoji}</span>
      <span>{meta.label}</span>
    </span>
  );
}

export function CapsuleCard({
  capsule,
  onOpen,
  index = 0,
}: {
  capsule: CapsuleDTO;
  onOpen: (c: CapsuleDTO) => void;
  index?: number;
}) {
  useNow(30000);
  const ready = isReadyToOpen(capsule);
  const opened = capsule.status === "opened";

  /* floating mini badges shared by both states */
  const badges = (
    <div className="absolute right-2.5 top-2.5 z-20 flex items-center gap-1">
      <span
        className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
        aria-hidden
      >
        {TYPE_META[capsule.type]?.emoji || "✨"}
      </span>
      {capsule.isSurprise && (
        <span
          className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
          aria-hidden
        >
          🎁
        </span>
      )}
      {capsule.recurring === "yearly" && (
        <span
          className="flex h-6 w-6 items-center justify-center rounded-full bg-black/45 text-xs backdrop-blur-sm"
          aria-hidden
        >
          🔁
        </span>
      )}
    </div>
  );

  /* ---- LOCKED: the whole card IS the capsule's own type,
          with the countdown living inside the shape ---- */
  if (!opened) {
    return (
      <motion.button
        type="button"
        onClick={() => onOpen(capsule)}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: Math.min(index * 0.05, 0.4), duration: 0.35 }}
        whileHover={{ y: -4 }}
        whileTap={{ scale: 0.985 }}
        className={`fm-card-hover group relative block w-full rounded-2xl text-left focus-visible:outline-ring ${
          ready ? "shadow-[0_0_28px_-6px] shadow-primary/50" : ""
        }`}
        aria-label={`Capsule: ${capsule.title}`}
      >
        {badges}
        <SealedCardVisual capsule={capsule} />
      </motion.button>
    );
  }

  /* ---- OPENED: the same form, caught in its opened state ---- */
  return (
    <motion.button
      type="button"
      onClick={() => onOpen(capsule)}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.05, 0.4), duration: 0.35 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.985 }}
      className="fm-card-hover group relative block w-full rounded-2xl text-left focus-visible:outline-ring"
      aria-label={`Capsule: ${capsule.title}`}
    >
      {badges}
      <OpenedCardVisual capsule={capsule} />
    </motion.button>
  );
}
